################################################################################ ----
################################################################################ ----
## Henry Scharf
##
## This script uses trajectories from stage 1 to obtain approximate posterior 
## inference for the movement model.
################################################################################ ----
################################################################################ ----
################### ----
## PRELIMINARIES ## ----
################### ----
## libraries ----
library(sp); library(rgdal); library(ABouncyRide)
Sys.setenv(TZ = "UTC")
time_interval <- c(as.POSIXct("2012-01-01", tz = "UTC", origin = "1970-01-01"),
                   as.POSIXct("2016-12-31", tz = "UTC", origin = "1970-01-01"))
## real data ----
data("pb_2012_2016")
## load paths + append source info ----
data("stage1_paths")
K <- length(mu_stars[[1]]$mu.star)
ids <- unique(pb$animal)
for(i in 1:length(mu_stars)){
  if(is.null(mu_stars[[i]])) next
  mu_stars[[i]]$source <- as.character(pb$Source[pb$animal == ids[i]][1])
}
## load ms ----
data("stage1_ms")
## look out for ms and mus with bad imputations, possibly due to problems with data ----
bad_mu_stars <- unlist(lapply(mu_stars, is.null))
mu_stars <- mu_stars[!bad_mu_stars]
if(length(mu_stars) != length(ms)){
  message("Warning: length(ms) != length(mu_stars)!")
}
bad_ms <- unlist(lapply(ms, length)) != K 
mu_stars <- mu_stars[!bad_ms]
ms <- ms[!bad_ms]
n_indiv <- length(mu_stars)
## shaping data ----
mus_K <- ms_K <- vector("list", 0)
kept_ind <- c()
for(i in 1:length(mu_stars)){
  mu_star <- mu_stars[[i]]
  ind <- which((mu_star$interp.times >= time_interval[1]) & 
                 (mu_star$interp.times <= time_interval[2]))
  if(length(ind) == 0) {message(i); next}
  kept_ind <- c(kept_ind, i)
  mus_K <- c(mus_K, list(lapply(mu_star$mu.star[1:K], function(path){matrix(path[ind, ], ncol = 2)})))
  ms_i <- ms[[i]]
  ms_K <- c(ms_K, list(
    sapply(1:K, function(k){
      ms_k_i <- ms_i[[k]]
      t(sapply(ind[-1], function(row){matrix(ms_k_i[row, ], ncol = 2)},
               simplify = T))
    }, simplify = F)))
}
n_indiv <- length(mus_K)
day_1 <- max(time_interval[1], 
             as.POSIXct(min(unlist(lapply(mu_stars, function(mu_star){
  min(mu_star$interp.times)}))), origin = "1970-01-01", tz = "UTC"))
day_last <- min(time_interval[2], 
                as.POSIXct(max(unlist(lapply(mu_stars, function(mu_star){
  max(mu_star$interp.times)}))), origin = "1970-01-01", tz = "UTC"))
all_days <- seq(day_1, day_last, by = "days")
days <- lapply(mu_stars[kept_ind], function(mu_star){
  which(all_days %in% mu_star$interp.times)
})
## check match between ms and mus and remove animals with one location ----
discrepency <- (unlist(lapply(mus_K, function(mu_K){dim(mu_K[[1]])[1]})) - 
                  (unlist(lapply(ms_K, function(m_K){dim(m_K[[1]])[1]})) + 1) == 0)
mus_K <- mus_K[(1:n_indiv)[discrepency]]
ms_K <- ms_K[(1:n_indiv)[discrepency]]
days <- days[(1:n_indiv)[discrepency]]
mu_stars <- mu_stars[discrepency]
kept_ind <- kept_ind[discrepency]
for(dis in (1:n_indiv)[!discrepency]){
  kept_ind[kept_ind > dis] <- kept_ind[kept_ind > dis] - 1
}
n_indiv <- length(mus_K)
mean_paths <- lapply(mus_K, function(mus_k){
  apply(array(unlist(mus_k), dim = c(dim(mus_k[[1]]), K)), 1:2, mean)
})
## number of original data points ----
message(n_indiv, " separate trajectories observed over ", signif((day_last - day_1)/365, 1), " years for a total of ",
        prettyNum(nrow(pb[(pb$POSIX >= day_1) & (pb$POSIX <= day_last), ]), big.mark = ","), " data points.")
########## ----
## MCMC ## ----
########## ----
## data ----
data <- list("mus" = mus_K, "days" = days, "day_1" = day_1, "day_last" = day_last, 
             "M" = NULL, "ms" = ms_K, "Qs" = NULL, "K" = K)
## initial values ----
initial_values <- list("sigsq_mu" = 15^2, "tausq" = 15^2, 
                       "summer_range" = as.numeric(c(format(as.POSIXct("2017-05-15", origin = "1970-01-01"), "%j"), 
                                                     format(as.POSIXct("2017-11-15", origin = "1970-01-01"), "%j"))),
                       "eigen_acs" = matrix(c(5e2, 5e2, 0,
                                              5e2, 5e2, 0), 3, 2),
                       "mu_acs" = matrix(c(1050, -1050, 50, -1650) 
                                         , 2, 2),
                       "ps" = rep(0.5, n_indiv))
## priors ----
mean_sigsq_mu <- 15^2; var_sigsq_mu <- ((15^2)/2)^2
mean_tausq <- 80^2; var_tausq <- ((80^2)/2)^2
mean_Sigma_ac <- 5e2; var_Sigma_ac <- 5e2^2
prior_params <- list("sigsq_mu" = c(2 + mean_sigsq_mu^2/var_sigsq_mu, mean_sigsq_mu * (1 + mean_sigsq_mu^2/var_sigsq_mu)), 
                     "tausq" = c(2 + mean_tausq^2/var_tausq, mean_tausq * (1 + mean_tausq^2/var_tausq)), 
                     "Sigma_acs" = list(c(mean_Sigma_ac^2 / var_Sigma_ac, mean_Sigma_ac / var_Sigma_ac),
                                       c(mean_Sigma_ac^2 / var_Sigma_ac, mean_Sigma_ac / var_Sigma_ac)),
                     "mu_acs" = matrix(c(1050, -1050, 0.5e4, 0, 0, 0.5e4, 
                                         50, -1650, 0.5e4, 0, 0, 0.5e4), ncol = 2), 
                     "summer_range" = c(initial_values$summer_range, 14^2, 0, 0, 14^2), 
                     "ps" = c(10, 10))
# ## initial likelihood ----
# summer <- make_summer(summer_range = initial_values$summer_range,
#                       day_1 = data$day_1, day_last = data$day_last)
# Prec_acs <- array(apply(initial_values$eigen_acs, 2, function(x){
#   d <- (initial_values$eigen_acs[1:2])^2
#   U <- matrix(c(cos(x[3]), sin(x[3]), -sin(x[3]), cos(x[3])), 2, 2)
#   Prec_ac <- U %*% (1/d * t(U))
# }), dim = c(2, 2, 2))
# lds <- sapply(1:K, function(k){
#   sapply(1:n_indiv, function(i){
#     get_ld_mu(mu = data$mus[[i]][[k]], sigsq_mu = initial_values$sigsq_mu, m = data$ms[[i]][[k]],
#               days = data$days[[i]], tausq = initial_values$tausq, summer = summer,
#               ps = initial_values$ps[i], mu_acs = initial_values$mu_acs, Prec_acs = Prec_acs)
#   })
# })
# problem_ids <- unique(which(lds == -Inf, arr.ind = T)[, 1])
# problem_ids
# detail <- sapply(1:K, function(k){
#   sapply(problem_ids, function(i){
#     mu <- data$mus[[i]][[k]]
#     m <- data$ms[[i]][[k]]
#     ps <- initial_values$ps[i]
#     tausq_vec <- rep(initial_values$tausq, length(data$days[[i]]))
#     tausq_vec[(which(!(days %in% summer)))] <- Inf
#     sapply(2:dim(mu)[1], function(t){
#       get_ld_mu_t(mu_t = mu[t, ], mu_tm1 = mu[t - 1, ], sigsq_mu = initial_values$sigsq_mu,
#                   m_t = m[t - 1, ], tausq = tausq_vec[t - 1], ps = c(1 - ps, ps),
#                   mu_acs = initial_values$mu_acs, Prec_acs = Prec_acs, verbose = F)
#     })
#   })
# })
# lds[problem_ids, ]
# matplot(lds, type = "l")
## fixed + tuning ----
fixed_params <- list("sigsq_mu" = F, "tausq" = F, "summer_range" = F,
                     "eigen_acs" = F, "Prec_acs" = F, "mu_acs" = T, "ps" = F)
tuning_params_init <- list("sigsq_mu" = 5, "tausq" = 300, "mu_acs" = c(20^2, 20^2), 
                           "eigen_acs" = c(1, 1), "summer_range" = c(6, 6),
                           "ps" = rep(0.25, n_indiv))
tuning_params_fixed <- c()
tuning_covs_init <- list("mu_acs" = array(c(diag(2), diag(2)), dim = c(2, 2, 2)), 
                         "eigen_acs" = array(c(diag(c(1e1, 1e1, 1)), 
                                               diag(c(1e1, 1e1, 1))), dim = c(3, 3, 2)),
                         "summer_range" = 1*diag(2))
## Number of iterations + batch size + used_iterations ----
N_iterations <- 5e4; batch_size <- min(N_iterations/2, 100)
verbose <- F; seed <- 2017; save_out_rate <- N_iterations / 10
used_iterations <- seq(N_iterations*0.5 + 1, N_iterations + 1, 2)
save_out_file <- "partial_fit.RData"
## fit [SLOW] ----
system.time({
  abr_fit <- abr_mcmc(N_iterations = N_iterations, data = data, initial_values = initial_values,
                      prior_params = prior_params, fixed_params = fixed_params, 
                      tuning_params_init = tuning_params_init, tuning_params_fixed = tuning_params_fixed,
                      batch_size = batch_size, seed = seed, verbose = verbose, 
                      save_out_file = save_out_file, save_out_rate = save_out_rate)
})
## composition samples of zs [SLOW] ----
ncores = 16
cl <- parallel::makeForkCluster(16)
system.time({
  zs <- parallel::parSapply(cl = cl, X = 1:n_indiv, FUN = function(i){
    sapply(X = used_iterations, FUN = function(iter){
      mu_i_iter <- abr_fit$data$mus[[i]][[abr_fit$chains$k[i, iter]]]
      m_i_iter <- abr_fit$data$ms[[i]][[abr_fit$chains$k[i, iter]]]
      summer_iter <- make_summer(abr_fit$chains$summer_range[, iter],
                                 day_1 = abr_fit$data$day_1, day_last = abr_fit$data$day_last)
      p0 <- get_ld_mu(mu = mu_i_iter, sigsq_mu = abr_fit$chains$sigsq_mu[iter], m = m_i_iter,
                      days = abr_fit$data$days[[i]], tausq = abr_fit$chains$tausq[iter],
                      summer = summer_iter, ps = 0, mu_acs = abr_fit$chains$mu_acs[, , iter],
                      Prec_acs = abr_fit$chains$Prec_acs[, , , iter])
      p1 <- get_ld_mu(mu = mu_i_iter, sigsq_mu = abr_fit$chains$sigsq_mu[iter], m = m_i_iter,
                      days = abr_fit$data$days[[i]], tausq = abr_fit$chains$tausq[iter],
                      summer = summer_iter, ps = 1, mu_acs = abr_fit$chains$mu_acs[, , iter],
                      Prec_acs = abr_fit$chains$Prec_acs[, , , iter])
      z_i <- sample(0:1, 1, prob = c(exp(p0 - max(p1, p0)), (exp(p1 - max(p1, p0)))))
      return(z_i)
    })
  })
})
parallel::stopCluster(cl)
abr_fit$chains$zs <- matrix(NA, nrow(abr_fit$chains$ps), ncol(abr_fit$chains$ps))
abr_fit$chains$zs[, used_iterations] <- t(zs)
## save fit ----
save(abr_fit, file = "stage2_fit.RData")
################### ----
## SUMMARY PLOTS ## ----
################### ----
## load fit [you must also run everything above "fit [SLOW]"] ----
data("stage2_fit")
N_iterations <- length(abr_fit$chains$sigsq_mu) - 1
# ## load partial fit [you must also run everything above "fit [SLOW]"] ----
# load(file = "partial_fit.RData")
# abr_fit <- out
# N_iterations <- length(abr_fit$chains$sigsq_mu) - 1
# highest_iter_reached <- which.min(!is.na(abr_fit$chains$sigsq_mu)) - 2
# message("highest iter reached = ", highest_iter_reached)
## diagnostic plots ----
get_ar <- function(chain){
  mean(diff(chain) != 0)
}
## burnin ----
burnin <- (1:(N_iterations + 1))[-used_iterations]
if(exists("highest_iter_reached")){
  used_iterations <- seq(highest_iter_reached * 0.2, 1 + min(highest_iter_reached, N_iterations), 20)
  # used_iterations <- (1:(1 + min(highest_iter_reached, N_iterations)))
}
## graphics device: parameters ----
pdf(file = "pb_diagnostics.pdf")
## tuning parameters ----
layout(matrix(1:8, 2, 4)); par(mar = c(4.1, 2.6, 1.1, 0.6))
## sigsq_mu
ars_sigsq_mu <- sapply(1:(floor(N_iterations/batch_size) + 1), function(batch){
  batch_index <- ((batch - 1)*batch_size + 1):(batch * batch_size) + 1
  get_ar(abr_fit$chains$sigsq_mu[batch_index])
})
plot(abr_fit$tuning_params$sigsq_mu, ars_sigsq_mu, 
     col = viridis::viridis(sum(!is.na(ars_sigsq_mu))),
     ylim = c(0, 1), xlab = expression(sigma[mu]^2))
abline(h = 0.44, lty = 2)
## tausq
ars_tausq <- sapply(1:(floor(N_iterations/batch_size) + 1), function(batch){
  batch_index <- ((batch - 1)*batch_size + 1):(batch * batch_size) + 1
  get_ar(abr_fit$chains$tausq[batch_index])
})
plot(abr_fit$tuning_params$tausq, ars_tausq, 
     col = viridis::viridis(sum(!is.na(ars_tausq))),
     ylim = c(0, 1), xlab = expression(tau))
abline(h = 0.44, lty = 2)
## mu_ac; sub_pop = 0
ars_mu_acs <- cbind(sapply(1:(floor(N_iterations/batch_size)), function(batch){
  batch_index <- ((batch - 1)*batch_size + 1):(batch * batch_size) + 1
  c(get_ar(abr_fit$chains$mu_acs[1, 0 + 1, batch_index]),
    get_ar(abr_fit$chains$mu_acs[1, 1 + 1, batch_index]))
}), c(NA, NA))
for(sub_pop in 0:1){
  plot(abr_fit$tuning_params$mu_acs[sub_pop + 1, ], ars_mu_acs[sub_pop + 1, ], 
       col = viridis::viridis(sum(!is.na(ars_mu_acs[sub_pop + 1, ]))),
       ylim = c(0, 1), main = paste("z =", sub_pop), xlab = "mu_acs")
  abline(h = 0.23, lty = 2)
}
## Prec_acs
ars_Prec_acs <- cbind(sapply(1:(floor(N_iterations/batch_size)), function(batch){
  batch_index <- ((batch - 1)*batch_size + 1):(batch * batch_size) + 1
  c(get_ar(abr_fit$chains$Prec_acs[1, 1, 0 + 1, batch_index]),
    get_ar(abr_fit$chains$Prec_acs[1, 1, 1 + 1, batch_index]))
}), c(NA, NA))
for(sub_pop in 0:1){
  if(is.null(abr_fit$tuning_params$eigen_acs)){
    plot(abr_fit$tuning_params$inv_chol_acs[sub_pop + 1, ], ars_Prec_acs[sub_pop + 1, ], 
         col = viridis::viridis(sum(!is.na(ars_Prec_acs[sub_pop + 1, ]))),
         ylim = c(0, 1), log = "x", main = paste("z =", sub_pop), xlab = "cov_acs")
  } else {
    plot(abr_fit$tuning_params$eigen_acs[sub_pop + 1, ], ars_Prec_acs[sub_pop + 1, ], 
         col = viridis::viridis(sum(!is.na(ars_Prec_acs[sub_pop + 1, ]))),
         ylim = c(0, 1), log = "x", main = paste("z =", sub_pop), xlab = "cov_acs")
  }
  abline(h = 0.23, lty = 2)
}
## summer_range
ars_summer <- c(sapply(1:(floor(N_iterations/batch_size)), function(batch){
  batch_index <- ((batch - 1)*batch_size + 1):(batch * batch_size) + 1
  get_ar(abr_fit$chains$summer_range[1, batch_index])
}), NA)
plot(abr_fit$tuning_params$summer_range[!is.na(ars_summer)], ars_summer[!is.na(ars_summer)], 
     col = viridis::viridis(sum(!is.na(ars_summer))),
     ylim = c(0, 1), xlab = "summer_range")
abline(h = 0.234, lty = 2)
## correlations ----
corrplot::corrplot(cor(cbind(t(abr_fit$chains$summer_range[, used_iterations]), 
                             abr_fit$chains$sigsq_mu[used_iterations], 
                             abr_fit$chains$tausq[used_iterations])), addCoef.col = 1)
## tuning params ps ----
subset <- sort(sample(1:nrow(abr_fit$tuning_params$ps), 8))
ars_ps <- t(sapply(subset, function(i) sapply(1:(floor(N_iterations/batch_size)), function(batch){
  batch_index <- ((batch - 1)*batch_size + 1):(batch * batch_size) + 1
  get_ar(abr_fit$chains$ps[i, batch_index])
})))
layout(matrix(1:length(subset), nrow = 2))
for(i in 1:length(subset)){
  plot(abr_fit$tuning_params$ps[i, -ncol(abr_fit$tuning_params$ps)], ars_ps[i, ], 
       col = viridis::viridis(sum(!is.na(ars_ps[i, ]))),
       ylim = c(0, 1), xlab = expression(p[i]^2), main = paste("i =", subset[i]))
  abline(h = 0.44, lty = 2)
}
## tuning covariances ----
## Prec_acs ----
layout(matrix(1:6, 3, 2)); par(mar = c(3.6, 3.6, 0.3, 0.3), oma = c(0, 0, 2, 0))
for(sub_pop in 0:1){
  plot(ellipse::ellipse(abr_fit$tuning_covs$eigen_acs[1:2, 1:2, 1 + sub_pop, 1]),
       type = "n", asp = 1, xlab = "", ylab = "",
       xlim = range(apply(abr_fit$tuning_covs$eigen_acs[1:2, 1:2, 1 + sub_pop, ], 3, ellipse::ellipse)),
       ylim = range(apply(abr_fit$tuning_covs$eigen_acs[1:2, 1:2, 1 + sub_pop, ], 3, ellipse::ellipse)))
  mtext(expression(lambda[1]), 1, 2.3, cex = 0.8); mtext(expression(lambda[2]), 2, 2.3, cex = 0.8)
  mtext(paste("z =", sub_pop), line = 1, xpd = T)
  for(batch in 1:sum(!is.na(ars_Prec_acs[sub_pop + 1, ]))){
    lines(ellipse::ellipse(abr_fit$tuning_covs$eigen_acs[1:2, 1:2, 1 + sub_pop, batch]), type = "l",
          asp = 1, col = viridis::viridis(sum(!is.na(ars_Prec_acs[sub_pop + 1, ])))[batch])
  }
  plot(ellipse::ellipse(abr_fit$tuning_covs$eigen_acs[c(1, 3), c(1, 3), 1 + sub_pop, 1]), type = "n",
       xlab = "", ylab = "",
       xlim = range(apply(abr_fit$tuning_covs$eigen_acs[c(1, 3), c(1, 3), 1 + sub_pop, ], 3, ellipse::ellipse)))
  mtext(expression(lambda[1]), 1, 2.3, cex = 0.8); mtext(expression(theta), 2, 2.3, cex = 0.8)
  for(batch in 1:sum(!is.na(ars_Prec_acs[sub_pop + 1, ]))){
    lines(ellipse::ellipse(abr_fit$tuning_covs$eigen_acs[c(1, 3), c(1, 3), 1 + sub_pop, batch]), type = "l",
          asp = 1, col = viridis::viridis(sum(!is.na(ars_Prec_acs[sub_pop + 1, ])))[batch])
  }
  plot(ellipse::ellipse(abr_fit$tuning_covs$eigen_acs[c(2, 3), c(2, 3), 1 + sub_pop, 1]), type = "n",
       xlab = "", ylab = "",
       xlim = range(apply(abr_fit$tuning_covs$eigen_acs[c(2, 3), c(2, 3), 1 + sub_pop, ], 3, ellipse::ellipse)))
  mtext(expression(lambda[2]), 1, 2.3, cex = 0.8); mtext(expression(theta), 2, 2.3, cex = 0.8)
  for(batch in 1:sum(!is.na(ars_Prec_acs[sub_pop + 1, ]))){
    lines(ellipse::ellipse(abr_fit$tuning_covs$eigen_acs[c(2, 3), c(2, 3), 1 + sub_pop, batch]), type = "l",
          asp = 1, col = viridis::viridis(sum(!is.na(ars_Prec_acs[sub_pop + 1, ])))[batch])
  }
}
## summer_range ----
layout(1); par(mar = c(3.1, 3.1, 3.1, 0.1))
plot(ellipse::ellipse(abr_fit$tuning_covs$summer_range[, , 1]), type = "n", asp = 1,
     main = "summer_range",
     xlim = range(apply(abr_fit$tuning_covs$summer_range, 3, ellipse::ellipse)),
     ylim = range(apply(abr_fit$tuning_covs$summer_range, 3, ellipse::ellipse)))
mtext("start", 1, 2.2); mtext("stop", 2, 2.2)
for(batch in 1:sum(!is.na(ars_summer))){
  lines(ellipse::ellipse(abr_fit$tuning_covs$summer_range[, , batch]), type = "l", 
        asp = 1, col = viridis::viridis(sum(!is.na(ars_summer)))[batch])
}
## parameter traces ----
layout(matrix(c(1:3, 3), 2, 2)); par(mar = c(4.1, 3.1, 1.4, 0.3))
## sigsq_mu
plot(used_iterations, abr_fit$chains$sigsq_mu[used_iterations],
     type = "l", main = expression(paste(sigma[mu]^2)), xlab = "", ylab = "")
text(x = par()$usr[1:2]%*%c(0.5, 0.5), y = par()$usr[3:4]%*%c(0.9, 0.1), 
     paste("ar =", get_ar(abr_fit$chains$sigsq_mu[used_iterations])))
text(x = par()$usr[1:2]%*%c(0.5, 0.5), y = par()$usr[3:4]%*%c(0.95, 0.05),
     paste("mean =", signif(mean(abr_fit$chains$sigsq_mu[used_iterations]), digits = 3)))
## tausq
plot(used_iterations, abr_fit$chains$tausq[used_iterations],
     type = "l", main = expression(tau^2), ylab = "", xlab = "iteration")
text(x = par()$usr[1:2]%*%c(0.5, 0.5), y = par()$usr[3:4]%*%c(0.9, 0.1), 
     paste("ar =", get_ar(abr_fit$chains$tausq[used_iterations])))
text(x = par()$usr[1:2]%*%c(0.5, 0.5), y = par()$usr[3:4]%*%c(0.95, 0.05),
     paste("mean =", signif(mean(abr_fit$chains$tausq[used_iterations]), digits = 3)))
## summer_range
matplot(used_iterations, t(abr_fit$chains$summer_range[, used_iterations]),
        type = "l", main = "summer", xlab = "iteration", ylab = "", ylim = c(0, 450),
        col = scales::muted(c("green", "red")), lty = 1, yaxt = "n")
abline(h = 365, col = "darkgray")
axis(2, at = c(1, 121, 213, 304, 365, 365 + 62), labels = c("Jan 1", "May 1", "Sept 1", "Nov 1", "Dec 31", "Mar 1"))
legend("bottomleft", col = rev(scales::muted(c("green", "red"))), lty = 1, bty = "n", 
       legend = rev(c("start", "stop")))
text(x = par()$usr[1:2]%*%c(0.5, 0.5), y = par()$usr[3:4]%*%c(0.9, 0.1), 
     paste("ar =", get_ar(abr_fit$chains$summer_range[1, used_iterations])))
## CI ----
CI <- t(as.data.frame(lapply(abr_fit$chains[c("sigsq_mu", "tausq")], 
                             quantile, probs = c(0.025, 0.5, 0.975), na.rm = T)))
CI <- rbind(CI, t(as.data.frame(lapply(abr_fit$chains[c("sigsq_mu", "tausq")], function(x){ 
                             quantile(sqrt(x), probs = c(0.025, 0.5, 0.975), na.rm = T)}))))
CI <- rbind(CI, t(as.data.frame(apply(abr_fit$chains$summer_range, 1, quantile, probs = c(0.025, 0.5, 0.975), na.rm = T))))
rownames(CI)[3:6] <- c("sigma_mu", "tau", paste("summer", c("start", "stop"), sep = "_"))
CI
## ps ----
layout(matrix(1:2, 2, 1), heights = c(1, 0.3)); par(mar = c(3.1, 2.6, 2.6, 0.6))
means <- rowMeans(abr_fit$chains$ps[, used_iterations])
medians <- apply(abr_fit$chains$ps[, used_iterations], 1, median)
modes <- floor((2 - 1e-6)*means)
ars_ps <- apply(abr_fit$chains$ps[, used_iterations], 1, get_ar)
plot_colors <- colorRamp(colors = c("#7f3b08", "#e08214", "#fee0b6", "#d8daeb", "#8073ac", "#2d004b"), 
                         interpolate = "spline")
plot(means, pch = 19, main = "sub-population", xlab = "", ylab = "Pr(CS)",
     ylim = c(0, 1), yaxt = "n", bty = "n", xaxt = "n", 
     col = rgb(plot_colors(means), maxColorValue = 255)
)
axis(2, at = 0:1, labels = c("SB", "CS"))
abline(h = 0.5, lwd = 2, lty = 2, col = scales::alpha(1, 0.3))
n_USFWS <- sum(unlist(lapply(mu_stars[kept_ind], function(x) x$source == "USFWS")))
abline(v = n_USFWS + 0.5, lwd = 2, col = scales::alpha(1, 0.3))
axis(1, at = c(n_USFWS/2, n_USFWS + (n_indiv - n_USFWS)/2), 
     labels = c("USFWS", "USGS"), tick = F)
points(abr_fit$chains$ps[, 1], col = "darkgreen", lwd = 2)
par(mar = c(0.6, 2.6, 0.2, 0.6))
plot(ars_ps, col = scales::muted("blue"), pch = 16, xlab = "", xaxt = "n", bty = "n",
     ylim = c(0, 1))
mtext("AR", 2, 1.7, cex = 0.8)
title(main = paste("mean(ar) =", signif(mean(ars_ps), 2)), cex.main = 0.9, xpd = T, line = -0.5)
abline(h = 0.44, lwd = 2, lty = 2, col = scales::alpha(1, 0.3))
## z ----
if(!is.null(abr_fit$chains$zs)){
  layout(1); par(mar = c(3.1, 2.6, 2.6, 0.6))
  means <- rowMeans(abr_fit$chains$zs[, used_iterations])
  medians <- apply(abr_fit$chains$ps[, used_iterations], 1, median)
  modes <- floor((2 - 1e-6)*means)
  plot_colors <- colorRamp(colors = c("#7f3b08", "#e08214", "#fee0b6", "#d8daeb", "#8073ac", "#2d004b"),
                           interpolate = "spline")
  plot(means, pch = 19, main = "sub-population", xlab = "", ylab = "Pr(CS)",
       ylim = c(0, 1), yaxt = "n", bty = "n", xaxt = "n",
       col = rgb(plot_colors(means), maxColorValue = 255)
       # col = gray.colors(length(means), 0.9, 0)[rank(abs(means - 0.5))]
  )
  axis(2, at = 0:1, labels = c("SB", "CS"))
  abline(h = 0.5, lwd = 2, lty = 2, col = scales::alpha(1, 0.3))
  n_USFWS <- sum(unlist(lapply(mu_stars[kept_ind], function(x) x$source == "USFWS")))
  abline(v = n_USFWS + 0.5, lwd = 2, col = scales::alpha(1, 0.3))
  axis(1, at = c(n_USFWS/2, n_USFWS + (n_indiv - n_USFWS)/2),
       labels = c("USFWS", "USGS"), tick = F)
  points(abr_fit$chains$ps[, 1], col = "darkgreen", lwd = 2)
}
## dev.off() ----
dev.off()
## graphics device: map ----
res <- 3
png(filename = "pb_map.png", height = 480 * 5 / 7 * res, width = 480 * res)
## mu_acs layout ----
layout(1); par(mar = c(0.1, 0.1, 0.1, 0.1))
## load map file and project data with proper +proj4 projection details + make colors ----
data("land")
pb.crs <- CRS(paste("+proj=aea +lat_1=60 +lat_2=90",
                    "+lat_0=82 +lon_0=-175 +x_0=0 +y_0=0",
                    "+ellps=GRS80 +datum=NAD83",
                    "+units=km +no_defs"))
land.proj <- spTransform(land, pb.crs)
## remove international dateline artifact ----
land.proj@polygons[[1381]]@Polygons[[1]]@coords <- rbind(land.proj@polygons[[1381]]@Polygons[[1]]@coords[1:2549, ], 
                                                         land.proj@polygons[[138]]@Polygons[[1]]@coords[1:320, ], 
                                                         land.proj@polygons[[1381]]@Polygons[[1]]@coords[2550:10297, ])
land.proj@polygons[[1380]]@Polygons[[1]]@coords <- rbind(land.proj@polygons[[1380]]@Polygons[[1]]@coords[1:12, ], 
                                                         land.proj@polygons[[61]]@Polygons[[1]]@coords[25:33, ], 
                                                         land.proj@polygons[[61]]@Polygons[[1]]@coords[1:20, ], 
                                                         land.proj@polygons[[1380]]@Polygons[[1]]@coords[13:17, ])
land.proj@polygons <- land.proj@polygons[-c(61, 138)]
land.proj@plotOrder <- 1:length(land.proj@polygons)
## plot map ----
bounding_box <- apply(array(unlist(lapply(mean_paths, function(x) apply(x, 2, range))), 
                            dim = c(2, 2, n_indiv)), 2, range)
bounding_box
plot(land.proj, xlim = c(-1.1e3, 1.5e3), ylim = c(-2.4e3, 0.3e3),
     bg = "dodgerblue4", lwd = 1/3 * res, col = "gray", border = "black")
## plot coastlines ----
coast_polygons <- sapply(60:62, function(i){land.proj@polygons[[i]]@Polygons[[1]]@coords})
# for(p in 1:length(coast_polygons)){
#   lines(coast_polygons[[p]], col = "red", lwd = 2)
# }
plot(land.proj, xlim = c(-1.8e3, 2.6e3), ylim = c(-2.1e3, 0.3e3),
     bg = NA, lwd = 1/3 * res, col = "gray", border = "black", add = T)
## add individual paths ----
plot_colors <- colorRamp(colors = c("#7f3b08", "#e08214", "#fee0b6", "#d8daeb", "#8073ac", "#2d004b"),
                         interpolate = "spline")
for(i in 1:n_indiv){
  # # mean path
  # lines(mean_paths[[i]], type = "l",
  #       pch = 19, lwd = 2 * res,
  #       col = scales::alpha(rgb(plot_colors(means[i]), maxColorValue = 255), 0.35))
  # all draws from stage 1
  for(k in 1:K){
    lines(abr_fit$data$mus[[i]][[k]], type = "l",
          pch = 19, lwd = 1.2 * res,
          col = scales::alpha(rgb(plot_colors(means[i]), maxColorValue = 255), 0.55/K))
  }
}
# ## add Sigma_acs ----
# ## z = 0
# plot_colors_0 <- viridis::viridis(length(used_iterations))
# ## z = 1
# plot_colors_1 <- viridis::magma(length(used_iterations))
# for(iter in sort(sample(used_iterations, min(length(used_iterations), 3e2)))){
#   lines(ellipse::ellipse(solve(abr_fit$chains$Prec_acs[, , 0 + 1, iter]),
#                          centre = abr_fit$chains$mu_acs[, 0 + 1, iter], level = 0.68),
#         col = plot_colors_0[which(iter == used_iterations)], lwd = res)
#   lines(ellipse::ellipse(solve(abr_fit$chains$Prec_acs[, , 1 + 1, iter]),
#                          centre = abr_fit$chains$mu_acs[, 1 + 1, iter], level = 0.68),
#         col = plot_colors_1[which(iter == used_iterations)], lwd = res)
# }
## add existing boundary line ----
if(!exists("boundary.proj")){
  boundary <- rgdal::readOGR(dsn = "../data/cs_sb_nb", layer = "cs_sb_nb")
  boundary.proj <- spTransform(boundary, pb.crs)
  boundary.proj@plotOrder <- as.integer(c(1, 3)) ## remove nb sea subpop
}
plot(boundary.proj, add = T, lwd = 1 * res, lty = 1, col = scales::alpha("gray", 0.4))
## calc central boundary lines ----
if(!exists("conic_ms")){
  conic_ms <- array(NA, dim = c(3, 3, length(used_iterations)))
  for(iter in used_iterations){
    conic_ms[, , which(iter == used_iterations)] <- 
      get_boundary_conic(mu = abr_fit$chains$mu_acs[, , iter],
                         Prec = abr_fit$chains$Prec_acs[, , , iter],
                         plot_boundary = F)$m
  }
}
## add summary central dividing line ----
conicPlot(apply(conic_ms, 1:2, mean), add = T, lwd = 3 * res,
          t = (pnorm(seq(-2, 2, l=2e2), sd = 1/4) - 0.5)*pi)
## compute uncertainty polygon [SLOW ~ 15min] ----
n_points <- 1e2 + 1
n_interp <- 1e3
center_conic <- conicPlot(apply(conic_ms, 1:2, mean),
                          t = (pnorm(seq(-3, 3, l=n_points/4), sd = 1) - 0.5)*pi,
                          type = "n", asymptotes = T, center = T)
if(!exists("bounds")){
  all_points <- sapply(2:length(used_iterations), function(iter){
    t(conicPlot(conic_ms[, , iter], t = (pnorm(seq(-2, 2, l=2e3), sd = 1/4) - 0.5)*pi, type = "n")$points)
  })
  all_points <- matrix(all_points, nrow = 2)
  probs <- c(0.025, 0.975); min_dist <- 4e2
  system.time({
    thetas <- atan(center_conic$asymptotes)
    Rs <- sapply(thetas, function(theta) matrix(c(cos(theta), sin(theta),
                                                  -sin(theta), cos(theta)), 2, 2),
                 simplify = F)
    boundarys <-
      list(cbind((par()$usr[3:4] + c(-200, 200) - center_conic$center[2] +
                    center_conic$asymptotes[1] * center_conic$center[1]) /
                   center_conic$asymptotes[1],
                 par()$usr[3:4] + c(-200, 200)),
           rbind(c(par()$usr[1] - 300, center_conic$asymptotes[2] *
                     (par()$usr[1] - 300 - center_conic$center[1]) + center_conic$center[2]),
                 c((par()$usr[4] + 200 - center_conic$center[2] +
                      center_conic$asymptotes[2] * center_conic$center[1]) /
                     center_conic$asymptotes[2], par()$usr[4] + 200)))
    boundarys_R <- sapply(1:2, function(l) t(Rs[[l]]) %*% t(boundarys[[l]]), simplify = F)
    bins <- sapply(1:2, function(l) seq(min(boundarys_R[[l]][1, ]), max(boundarys_R[[l]][1, ]),
                                        l=n_points))
    bounds <- array(sapply(1:2, function(l){
      all_points_R <- t(Rs[[l]]) %*% all_points
      bound <- sapply(2:n_points, function(point_i){
        index2consider <- which(all_points_R[1, ] <= bins[point_i, l] &
                                  all_points_R[1, ] >= bins[point_i - 1, l] &
                                  abs(all_points_R[2, ] - mean(boundarys_R[[l]][2, ])) < min_dist)
        # plot(t(all_points_R[, index2consider]))
        # points(bins[(point_i - 1):point_i, l], boundarys_R[[l]][2, ], col = 2, pch = 16)
        q <- quantile(all_points_R[2, index2consider], probs = probs)
        bound_pts <- cbind(mean(bins[(point_i - 1):point_i, l]), q)
        out <- Rs[[l]] %*% t(bound_pts)
      })
      array(bound, dim = c(2, 2, n_points - 1))
    }, simplify = T), dim = c(2, 2, n_points - 1, 2))
    bounds_interp <- array(apply(bounds, c(1, 2, 4), function(x) approx(x = x, n = n_interp)$y), dim = c(n_interp, 2, 4))
    quads <- matrix(c(143, -1540, -463, 1409,
                      387, -148, -1818, -577), ncol = 2)
    distances_from_quads <- array(apply(quads, 1, function(quad){
      sapply(1:4, function(l){
        sqrt(rowSums((quad - bounds_interp[, , l])^2))
      })
    }), dim = c(n_interp, 4, 4))
    bounds_all <- apply(bounds_interp, 2, function(x) x)
    hull <- apply(quads, 1, function(quad){
      y <- t(t(bounds_all) - quad)
      y <- y/(rowSums(y^2)^0.51)
      bounds_all[chull(y), ]
    })
  })
}
## plot uncertainty polygon ----
polygon(c(hull[[1]][rev(order(hull[[1]][, 1])), 1],
          hull[[2]][rev(order(hull[[2]][, 2])), 1],
          hull[[3]][order(hull[[3]][, 1]), 1],
          hull[[4]][, 1]),
        c(hull[[1]][rev(order(hull[[1]][, 1])), 2],
          hull[[2]][rev(order(hull[[2]][, 2])), 2],
          hull[[3]][order(hull[[3]][, 1]), 2],
          hull[[4]][, 2]), lty = 2, lwd = 2 * res, col = scales::alpha("gray", 0))
## dev.off ----
dev.off()
## graphics device: sub-population probabilities ----
pdf(file = "sub-population_probs.pdf", width = 7, height = 5)
## plot ----
layout(1); par(mar = c(3.1, 2.6, 2.6, 0.6))
means <- rowMeans(abr_fit$chains$zs[, used_iterations])
medians <- apply(abr_fit$chains$zs[, used_iterations], 1, median)
modes <- floor((2 - 1e-6)*means)
plot_colors <- colorRamp(colors = c("#7f3b08", "#e08214", "#fee0b6", "#d8daeb", "#8073ac", "#2d004b"), 
                         interpolate = "spline")
plot(means, pch = 19, main = "sub-population", xlab = "", ylab = "Pr(CS)",
     ylim = c(0, 1), yaxt = "n", bty = "n", xaxt = "n", 
     col = rgb(plot_colors(means), maxColorValue = 255)
     # col = gray.colors(length(means), 0.9, 0)[rank(abs(means - 0.5))]
)
axis(2, at = 0:1, labels = c("SB", "CS"))
abline(h = 0.5, lwd = 2, lty = 2, col = scales::alpha(1, 0.3))
n_USFWS <- sum(unlist(lapply(mu_stars[kept_ind], function(x) x$source == "USFWS")))
abline(v = n_USFWS + 0.5, lwd = 2, col = scales::alpha(1, 0.3))
axis(1, at = c(n_USFWS/2, n_USFWS + (n_indiv - n_USFWS)/2), 
     labels = c("USFWS", "USGS"), tick = F)
# points(modes, pch = 4, cex = 1)
# legend(par()$usr[1], par()$usr[3:4] %*% c(0.85, 0.15), bty = "n", lty = NA, col = rgb(plot_colors(1:0), maxColorValue = 255),
#        pch = c(19, 19), pt.cex = c(1, 1), lwd = c(1, 1), legend = c("posterior mode", "posterior mean"))
## dev.off ----
dev.off()