################################################################################ ----
################################################################################ ----
## Henry Scharf
##
## This script pre-computes the locations, $\mathbf{m}_i(t)$, used to linearize
## the landscape feature. 
################################################################################ ----
################################################################################ ----
################### ----
## PRELIMINARIES ## ----
################### ----
## libraries + n_cores ----
library(ABouncyRide); library(rgdal); library(sp); library(rgeos); library(pdist)
############### ----
## all years ## ----
############### ----
## dates for ice ----
PI_date <- "20181129_210643"
years <- 2012:2016
days.per.year <- c(366, 365, 365, 365, 366)
days <- unlist(sapply(days.per.year, function(dpy){1:dpy}))
dates <- paste(rep(years, days.per.year), formatC(days, width = 3, format = "d", flag = "0"), sep = "")
dates.POSIX <- as.POSIXct(dates, format = "%Y%j", tz = "UTC")
K <- 24
## load joined ice + shore ----
all_lines_ice_coast <- NULL
for(year in years){
  load(paste0(year, "_lines_ice_coast.RData", sep = ""))
  all_lines_ice_coast <- c(all_lines_ice_coast, lines_ice_coast)
  rm(lines_ice_coast)
  gc()
}
## load interpolated paths ----
data("stage1_paths")
## make imputations into spatial object ----
system.time({
  mu_stars_sp <- lapply(mu_stars, function(indiv){
    lapply(indiv$mu.star, function(path){
      path.df <- data.frame(lon = path[, 1], lat = path[, 2])
      coordinates(path.df) <- ~lon+lat
      proj4string(path.df) <- CRS(paste("+proj=aea +lat_1=60 +lat_2=90",
                                        "+lat_0=82 +lon_0=-175 +x_0=0 +y_0=0",
                                        "+ellps=GRS80 +datum=NAD83",
                                        "+units=km +no_defs"))
      return(path.df)
    })
  })
})
## get ms for everyday [SLOW] ----
system.time({
  subset <- which(sapply(1:length(mu_stars), function(i){
    sum(mu_stars[[i]]$interp.times %in% dates.POSIX) > 0
  }))
  ms <- vector("list", length(subset))
  for(i in 1:length(subset)){
    message("Now computing ms for individual ", i, " of ", length(subset), ". [", Sys.time(), "]")
    relevant_times <- mu_stars[[subset[i]]]$interp.times[mu_stars[[subset[i]]]$interp.times %in% dates.POSIX]
    ms[[i]] <-
      sapply(1:min(K, length(mu_stars_sp[[subset[i]]])), function(path.i){
        t(sapply(relevant_times, function(t){
          all_lines <- do.call("rbind", lapply(all_lines_ice_coast[[which(t == dates.POSIX)]]@lines, function(group){
            do.call("rbind", lapply(group@Lines, function(line){line@coords}))
          }))
          distances <- pdist(X = mu_stars_sp[[subset[i]]][[path.i]][which(t == relevant_times), ]@coords, 
                             Y = all_lines)@dist
          all_lines[which.min(distances), ]
        }))
      }, simplify = F)
  }
})
## save output ----
save(ms, file = "stage1_ms.RData")