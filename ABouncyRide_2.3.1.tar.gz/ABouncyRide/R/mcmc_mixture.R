################################################################################ ----
################################################################################ ----
## Henry Scharf
## 
## This script fits paths to the ice boundary model using mcmc.
## The organization is as follows. There is a general Random Walk sampler function, which calls a specicialized function for each parameter that computes the log full conditional for a given proposal. 
################################################################################ ----
################################################################################ ----
#' Metropolis sampler with normal proposal distribution and diagonal proposal variance.
#' This sampler accepts both vectors and scalars. 
#'
#' @param prev previous value (either scalar or vector)
#' @param tune tuning parameter (if \code{prev} is a vector, this can either be a scalar, or a vector of the same length)
#' @param get_ld_fc function to evaluate for Metropolis ratio. The first argument should be where \code{prev} goes.
#' @param ld_fc_prev log density for previous value (if \code{NULL}, will be calculated)
#' @param ... arguments passed to \code{get_ld_fc()}
#'
#' @return list: \code{draw} is vector of same length as \code{prev}, \code{ld_fc} is the log density full conditional
#' @export
sample_rw <- function(prev, tune, get_ld_fc, ld_fc_prev = NULL, verbose = F, ...){
  excess.num <- excess.den <- NULL
  proposal <- rnorm(length(prev), mean = prev, sd = tune)
  num <- get_ld_fc(proposal, ...)
  if(is.list(num)){
    excess.num <- num[-1]; num <- num[[1]]
  }
  den <- ld_fc_prev
  if(is.null(den) || length(den) == 0){
    den <- get_ld_fc(prev, ...)
    if(is.list(den)){
      excess.den <- den[-1]; den <- den[[1]]
    }
  }
  prob <- min(exp(num - den), 1)
  if(verbose){
    message(paste(c("proposal =", proposal, "num =", num, "\n prev =", prev, "den =", den, "\n prob =", prob, 
                  "\n ld function:", as.character(substitute(get_ld_fc)))))
  }
  accept <- runif(n = 1) < prob
  if(accept){
    return(list("draw" = proposal, "ld_fc" = num, "excess" = excess.num))
  } else {
    return(list("draw" = prev, "ld_fc" = den, "excess" = excess.den))
  }
}

#' Metropolis sampler with normal proposal distribution and general proposal variance.
#' This sampler accepts both vectors and scalars. 
#'
#' @param prev previous value (vector)
#' @param tune_cov covariance matrix for proposal distribution. Dimensions should equal length of \code{prev}.
#' @param get_ld_fc function to evaluate for Metropolis ratio. The first argument should be where \code{prev} goes.
#' @param ld_fc_prev log density for previous value (if \code{NULL}, will be calculated)
#' @param ... arguments passed to \code{get_ld_fc()}
#' @param verbose_sampler logical. Print information about sampler.
#'
#' @return list: \code{draw} is vector of same length as \code{prev}, \code{ld_fc} is the log density full conditional
#' @export
sample_RW <- function(prev, tune_cov, get_ld_fc, ld_fc_prev = NULL, verbose_sampler = F, ...){
  excess.num <- excess.den <- NULL
  proposal <- c(mvnfast::rmvn(n = 1, mu = c(prev), sigma = tune_cov))
  if(!is.null(dim(prev))){
    proposal <- array(proposal, dim = dim(prev))
  }
  num <- get_ld_fc(proposal, ...)
  if(is.list(num)){
    excess.num <- num[-1]; num <- num[[1]]
  }
  den <- ld_fc_prev
  if(is.null(den) || length(den) == 0){
    den <- get_ld_fc(prev, ...)
    if(is.list(den)){
      excess.den <- den[-1]; den <- den[[1]]
    }
  }
  prob <- min(exp(num - den), 1)
  if(verbose_sampler){
    message("\n proposal = ", paste(c("", rep(", ", length(proposal) - 1)), proposal, sep = ""))
    message("\n prev = ", paste(c("", rep(", ", length(prev) - 1)), prev, sep = ""))
    message(paste("\n num =", num, 
                  "\n den =", den, "\n prob =", prob, 
                  "\n ld function:", as.character(substitute(get_ld_fc))))
  }
  accept <- runif(n = 1) < prob
  if(accept){
    return(list("draw" = proposal, "ld_fc" = num, "excess" = excess.num))
  } else {
    return(list("draw" = prev, "ld_fc" = den, "excess" = excess.den))
  }
}

#' Update tuning parameter
#'
#' @param batch 
#' @param batch_no 
#' @param tuning_param 
#' @param gain 
#' @param direction set to -1 for precision tuning parameters
#'
#' @return scalar
#' @export
update_tuning <- function(batch, batch_no, tuning_param = 1, gain = 1, direction = 1) {
  batch_size <- length(batch)
  accepted <- sum(diff(batch) != 0)
  log_tuning_param <- log(tuning_param)
  adjust <- (batch_no + 1)^(-0.5)
  if(accepted / (batch_size - 1) > 0.44){
    new_tuning_param <- exp(log_tuning_param + direction*gain*adjust)
  } else {
    new_tuning_param <- exp(log_tuning_param - direction*gain*adjust);
  }
  return(new_tuning_param);
}

#' Update tuning parameter
#'
#' @param batch matrix of dimensions (length of parameter vector, batch size)
#' @param batch_no integer
#' @param tuning_param current value of the scalar multiplying the tuning covariance matrix.
#' @param tune_cov current covariance matrix for tuning.
#' @param target target acceptance rate. Default is 0.23.
#' @param gain 
#' @param direction set to -1 for precision tuning parameters
#'
#' @return scalar
#' @export
update_TUNING <- function(batch, batch_no, tuning_param = 1, tune_cov = diag(rep(1, dim(batch)[1])), 
                          target = 0.23, gain = 1, verbose = F) {
  batch_size <- dim(batch)[2]
  accepted <- t(apply(batch, 1, function(x) diff(x) != 0))
  if(length(which(apply(accepted, 2, function(x) x == x[1]) == FALSE)) != 0){
    if(verbose) message("Acceptance rate error in update_TUNING(). Parameters do not appear to be accepted as a block.")
  } 
  log_tuning_param <- log(tuning_param)
  adjust <- (batch_no + 1)^(-0.5)
  new_tune_cov <- tune_cov + adjust * (cov(t(batch)) - tune_cov)
  new_tuning_param <- exp(log_tuning_param + gain*adjust*sign(sum(accepted[1, ]) / (batch_size - 1) - target))
  return(list("param" = new_tuning_param, "tune_cov" = new_tune_cov));
}

#' Get function propotional to likelihood for one step. Used only for exact likelihood samplers.
#' 
#' Used within \code{get_ld_mu_t()}, not intended for use on its own.
#'
#' @param x location \eqn{\mu(t)}
#' @param M_t ice manifold at time t
#' @param mu_avail mean of availability function component
#' @param Prec_avail 2 x 2 inverse of the variance-covariance matrix associated with combination of movement and activity center
#' @param tausq variance associated with ice-boundary availability function
#'
#' @return scalar
#' @export
get_prop_lh <- function(x, M_t, mu_avail, Prec_avail, tausq, log = F){
  h <- min(colSums((t(M_t) - as.numeric(x))^2))
  if(log){
    return(-1/2 * (x - mu_avail) %*% Prec_avail %*% (x - mu_avail) - h/2/tausq)
  }
  return(exp(-1/2 * (x - mu_avail) %*% Prec_avail %*% (x - mu_avail) - h/2/tausq))
}

#' Compute the log density of \eqn{\boldsymbol\mu_t}.
#'
#' @param mu_t 
#' @param mu_tm1 
#' @param sigsq_mu variance of \eqn{\mu(t - 1)}
#' @param M_t two-column matrix giving discretized \eqn{\mathcal{M}(t)}
#' @param m_t closest location on the ice boundary \eqn{\mathcal{M}(t)} to \eqn{\mu(t - 1)}
#' @param tausq affinity for \eqn{\mathcal{M}(t)}
#' @param Prec_mv precision component for just movement and ice, no activity center. Can be pre-computed for known trajectories + known tausq.
#' @param ps vector of \code{n_sub_pops} probabilities corresponding to each class (should sum to 1).
#' @param mu_acs means of activity centers provided as matrix with two rows (easting, northing).
#' @param Prec_acs precision matrices associated with activity centers given as array with dimensions \code{2, 2, n_sub_pops}.
#' @param calc_det logical. Should we bother with the determinant of Sigma? Not needed for certain variable updates.
#' @param verbose logical. Should messages be printed giving some info about how the functions are working.
#'
#' @return scalar
old_get_ld_mu_t <- function(mu_t, mu_tm1 = NULL, sigsq_mu, 
                            M_t = NULL, m_t = NULL, tausq, Prec_mv = NULL, 
                            ps, mu_acs, Prec_acs, verbose = F){
  if(is.null(m_t)){
    if(verbose){
      message("Computing location of m_t in get_ld_mu_t().")
    }
    m_indicator <- which.min(colSums((mu_tm1 - t(M_t))^2))
    m_t <- M_t[m_indicator, ]
  } 
  if(is.null(Prec_mv)){
    if(verbose){
      message("Computing Prec_mv in get_ld_mu_t().")
    }
    theta <- atan2(m_t[2] - mu_tm1[2], m_t[1] - mu_tm1[1])
    if(verbose){
      message(paste("theta =", theta))
    }
    R <- matrix(c(cos(theta), sin(theta), -sin(theta), cos(theta)), 2, 2)
    Prec_mv <- R %*% matrix(c((sigsq_mu^-1 + tausq^-1), 0, 0, sigsq_mu^(-1)), 2, 2) %*% t(R)
  }
  alpha <- sigsq_mu / (sigsq_mu + tausq)
  mean_mv <- c(alpha * m_t + (1-alpha) * mu_tm1)
  Precs <- array(c(Prec_mv) + c(Prec_acs), dim = dim(Prec_acs))
  Sigmas <- array(apply(Precs, 3, solve), dim = dim(Precs))
  out <- log(sum(sapply(1:dim(Precs)[3], function(sub_pop){
    mean <- Sigmas[, , sub_pop] %*% (Prec_mv %*% mean_mv + Prec_acs[, , sub_pop] %*% mu_acs[, sub_pop])
    ps[sub_pop] * mvnfast::dmvn(X = mu_t, mu = mean, sigma = Sigmas[, , sub_pop], log = F)
  })))
  # Sigmas <- array(apply(Precs, 3, solve), dim = dim(Precs))
  # dets <- Precs[1, 1, ] * Precs[2, 2, ] - Precs[1, 2, ] * Precs[2, 1, ]
  # kernels <- h 
  # out <- log(ps %*% out)
  return(out)
}

#' Compute the log density of \eqn{\boldsymbol\mu} for all times t > 1..
#'
#' @param mu matrix with dimensions # times + 1, 2
#' @param sigsq_mu 
#' @param M array with dimensions (# locations, 2, # times).
#' @param m matrix with dimension (# times, 2).
#' @param tausq either a scalar, or a vector of values with length # times
#' @param Prec_mv precision component for just movement and ice, no activity center. Can be pre-computed for known trajectories + known tausq.
#' @param ps vector of \code{n_sub_pops} probabilities corresponding to each class (should sum to 1).
#' @param mu_acs means of activity centers provided as matrix with two rows (easting, northing).
#' @param Prec_acs precision matrices associated with activity centers given as array with dimensions \code{2, 2, n_sub_pops}.
#' @param days 
#' @param summer 
#'
#' @return scalar
old_get_ld_mu <- function(mu, sigsq_mu = NULL, M = NULL, m = NULL, days, tausq, summer,
                      Prec_mv = NULL, ps, mu_acs, Prec_acs, apply_option = T){
  if(length(ps) == dim(Prec_acs)[3] - 1){
    ps <- c(1 - sum(ps), ps)
  }
  tausq_vec <- rep(tausq, length(days))
  tausq_vec[(which(!(days %in% summer)))] <- Inf
  if(apply_option){
    ## apply option ----
    ld <- sum(sapply(2:dim(mu)[1], function(t){
      old_get_ld_mu_t(mu_t = mu[t, ], mu_tm1 = mu[t - 1, ], sigsq_mu = sigsq_mu,
                  m_t = m[t - 1, ], tausq = tausq_vec[t - 1],
                  ps = ps, mu_acs = mu_acs, Prec_acs = Prec_acs)
    }))
  } else {
    ## vectorize option ----
    TIME <- dim(mu)[1] - 1
    thetas <- atan((m[, 2] - mu[-TIME, 2]) / (m[, 1] - mu[-TIME, 1]))
    cos_thetas <- cos(thetas); sin_thetas <- sin(thetas)
    cos_sq_thetas <- cos_thetas^2; sin_sq_thetas <- sin_thetas^2; sin_cos_thetas <- cos_thetas * sin_thetas
    Q_11 <- sigsq_mu^-1 + tausq_vec[-1]^-1; Q_22 <- sigsq_mu^(-1); Q_11_minus_22 <- Q_11 - Q_22
    Prec_mvs <- Matrix::bdiag(sapply(1:(TIME), function(t){
      matrix(c(Q_11[t]*cos_sq_thetas[t] + Q_22*sin_sq_thetas[t], rep((Q_11_minus_22[t]) * sin_cos_thetas[t], 2),
               Q_11[t]*sin_sq_thetas[t] + Q_22*cos_sq_thetas[t]), 2, 2)
    }, simplify = F))
    alphas <- sigsq_mu / (sigsq_mu + tausq_vec[-1])
    mean_mvs <- alphas * m + (1 - alphas) * mu[-TIME, ]
    ##
    Precs <- list(Prec_mvs + diag(TIME) %x% Matrix::bdiag(Prec_acs[, , 1]),
                  Prec_mvs + diag(TIME) %x% Matrix::bdiag(Prec_acs[, , 2]))
    Sigmas <- lapply(Precs, Matrix::solve)
    mu_minus_means <- sapply(1:2, function(sub_pop){
      mean <- Sigmas[[sub_pop]] %*% (Prec_mvs %*% c(t(mean_mvs)) +
                                       c(rep(mu_acs[, sub_pop] %*% Prec_acs[, , sub_pop], TIME)))
      as.numeric(c(t(mu[-1, ])) - mean)
    }, simplify = F)
    
    lds_kernels <- cbind(colSums(matrix(mu_minus_means[[1]] * (Precs[[1]] %*% mu_minus_means[[1]]), nrow = 2)),
                         colSums(matrix(mu_minus_means[[2]] * (Precs[[2]] %*% mu_minus_means[[2]]), nrow = 2)))
    if(TIME > 1){
      ds_dets <- cbind(Matrix::diag(Precs[[1]])[2*(1:TIME) - 1] * Matrix::diag(Precs[[1]])[2*(1:TIME)] - 
                         Matrix::diag(Precs[[1]][-1, -2*TIME])[2*(1:TIME) - 1]^2,
                       Matrix::diag(Precs[[2]])[2*(1:TIME) - 1] * Matrix::diag(Precs[[2]])[2*(1:TIME)] - 
                         Matrix::diag(Precs[[2]][-1, -2*TIME])[2*(1:TIME) - 1]^2)
    } else {
      ds_dets <- cbind(Precs[[1]][1, 1] *Precs[[1]][2, 2] - Precs[[1]][1, 2]^2,
                       Precs[[2]][1, 1] *Precs[[2]][2, 2] - Precs[[2]][1, 2]^2)
    }
    ld <- sum(log((1/2/pi * sqrt(ds_dets) * exp(-0.5 * lds_kernels)) %*% ps))
  }
  ##
  return(ld)
}

#' Compute the log density of \eqn{\sigma^2_\mu}.
#'
#' @param sigsq_mu 
#' @param mus list of matrices
#' @param days list of vectors indexing days in master ice array, M
#' @param ms list of matrices with 2 columns. Each matrix gives the pre-computed closest locations on the ice boundary to the true location on the previous day.
#' @param tausq 
#' @param summer 
#' @param ps vector of \code{n_sub_pops} probabilities corresponding to each class (should sum to 1).
#' @param mu_acs means of activity centers provided as matrix with two rows (easting, northing).
#' @param Prec_acs precision matrices associated with activity centers given as array with dimensions \code{2, 2, n_sub_pops}.
#' @param prior_params Inverse-gamma distribution prior parameters
#' @param cl default is \code{NULL}, but a cluster may be passed for parallel computation
#'
#' @return scalar
#' @export
get_ld_fc_sigsq_mu <- function(sigsq_mu, mus, days, ms = NULL, tausq, summer, 
                               ps, mu_acs, Prec_acs, prior_params, cl = NULL){
  if(sigsq_mu <= 0){
    return(-Inf)
  } else {
    if(is.null(cl)){
    sum(
      sapply(1:length(mus), function(i){
      get_ld_mu(mu = mus[[i]], sigsq_mu = sigsq_mu, 
                m = ms[[i]], days = days[[i]], tausq = tausq, summer = summer, 
                ps = ps[i], mu_acs = mu_acs, Prec_acs = Prec_acs)  
    })) - 
      (prior_params[1] + 1) * log(sigsq_mu) - prior_params[2] / sigsq_mu
    } else {
      sum(parallel::parSapply(cl = cl, 1:length(mus), function(i){
        get_ld_mu(mu = mus[[i]], sigsq_mu = sigsq_mu, 
                  m = ms[[i]], days = days[[i]], tausq = tausq, summer = summer, 
                  ps = ps[i], mu_acs = mu_acs, Prec_acs = Prec_acs)  
      })) - 
        (prior_params[1] + 1) * log(sigsq_mu) - prior_params[2] / sigsq_mu
    }
  }
}

#' Compute the log density of \eqn{\tau^2}.
#'
#' @param tausq 
#' @param mus list of matrices
#' @param days list of vectors indexing days in master ice array, M
#' @param ms list of matrices with 2 columns. Each matrix gives the pre-computed closest locations on the ice boundary to the true location on the previous day.
#' @param sigsq_mu 
#' @param ps vector of \code{n_sub_pops} probabilities corresponding to each class (should sum to 1).
#' @param mu_acs means of activity centers provided as matrix with two rows (easting, northing).
#' @param Prec_acs precision matrices associated with activity centers given as array with dimensions \code{2, 2, n_sub_pops}.
#' @param prior_params Inverse-gamma distribution prior parameters
#' @param cl default is \code{NULL}, but a cluster may be passed for parallel computation
#'
#' @return scalar
#' @export
get_ld_fc_tausq <- function(tausq, summer, mus, days, ms = NULL, sigsq_mu,
                            ps, mu_acs, Prec_acs, prior_params, cl = NULL){
  if(tausq <= 0){
    return(-Inf)
  } else {
    if(is.null(cl)){
      sum(sapply(1:length(mus), function(i){
        get_ld_mu(mu = mus[[i]], sigsq_mu = sigsq_mu, 
                  m = ms[[i]], days = days[[i]], tausq = tausq, summer = summer, 
                  ps = ps[i], mu_acs = mu_acs, Prec_acs = Prec_acs)  
      })) - (prior_params[1] + 1) * log(tausq) - prior_params[2] / tausq
    } else {
      sum(parallel::parSapply(cl = cl, 1:length(mus), function(i){
        get_ld_mu(mu = mus[[i]], sigsq_mu = sigsq_mu, 
                  m = ms[[i]], days = days[[i]], tausq = tausq, summer = summer, 
                  ps = ps[i], mu_acs = mu_acs, Prec_acs = Prec_acs)  
      })) - (prior_params[1] + 1) * log(tausq) - prior_params[2] / tausq
    }
  }
}

#' Make Summer
#'
#' @param summer_range ordered 2-vector 
#' @param day_1 time in class \code{POSIXct()}
#' @param day_last time in class \code{POSIXct()}
#'
#' @return vector of days corresponding to summer in a modular arithmetic sort of way
#' @export
make_summer <- function(summer_range, day_1, day_last){
  days_in_year <- as.numeric(format(seq(day_1, day_last, by = "day"), "%j"))
  if(max(summer_range) <= 365){
    (1:length(days_in_year))[which((days_in_year > summer_range[1]) & (days_in_year < summer_range[2]))]
  } else {
    (1:length(days_in_year))[which(!((days_in_year > summer_range[2] - 365) & (days_in_year < summer_range[1])))]
  } 
}

#' Compute the log density of \eqn{\Sigma_{ac}(i)}.
#'
#' @param eigen_ac lower cholesky matrix for precision matrix associated with activity center component
#' @param sub_pop index of sub-population (0 or 1).
#' @param mus list of matrices
#' @param days list of vectors indexing days in master ice array, M
#' @param ms list of matrices with 2 columns. Each matrix gives the pre-computed closest locations on the ice boundary to the true location on the previous day.
#' @param sigsq_mu 
#' @param tausq 
#' @param ps vector of \code{n_sub_pops} probabilities corresponding to each class (should sum to 1).
#' @param mu_acs means of activity centers provided as matrix with two rows (easting, northing).
#' @param Prec_acs precision matrices associated with activity centers given as array with dimensions \code{2, 2, n_sub_pops}.
#' @param prior_params Inverse-gamma distribution prior parameters
#' @param cl default is \code{NULL}, but a cluster may be passed for parallel computation
#'
#' @return scalar
#' @export
get_ld_fc_Sigma_ac <- function(eigen_ac, sub_pop, mus, days, ms = NULL, sigsq_mu, tausq, summer,
                               ps, mu_acs, Prec_acs, prior_params, verbose = F, cl = NULL){
  if(length(eigen_ac) != 3){
    stop("Wrong number (!= 3) of parameters passed as proposal in get_ld_fc_Sigma_ac().")
  }
  if(eigen_ac[3] < 0 || eigen_ac[3] >= pi/2 || min(eigen_ac[1:2]) <= 0){
    return(-Inf)
  }
  d <- (eigen_ac[1:2])^2
  U <- matrix(c(cos(eigen_ac[3]), sin(eigen_ac[3]), -sin(eigen_ac[3]), cos(eigen_ac[3])), 2, 2)
  Prec_ac <- U %*% (1/d * t(U))
  Prec_acs[, , sub_pop + 1] <- Prec_ac
  if(is.null(cl)){
    sum(sapply(1:length(mus), function(i){
      get_ld_mu(mu = mus[[i]], sigsq_mu = sigsq_mu, 
                m = ms[[i]], days = days[[i]], tausq = tausq, summer = summer, 
                ps = ps[i], mu_acs = mu_acs, Prec_acs = Prec_acs)  
    })) + prior_params[1] * log(prod(eigen_ac[1:2])) - prior_params[2] * sum(eigen_ac[1:2])
  } else {
    sum(parallel::parSapply(cl = cl, 1:length(mus), function(i){
      get_ld_mu(mu = mus[[i]], sigsq_mu = sigsq_mu, 
                m = ms[[i]], days = days[[i]], tausq = tausq, summer = summer, 
                ps = ps[i], mu_acs = mu_acs, Prec_acs = Prec_acs)  
    })) + prior_params[1] * log(prod(eigen_ac[1:2])) - prior_params[2] * sum(eigen_ac[1:2])
  }
}

#' Compute the log density of \eqn{\mu_{ac}}.
#'
#' @param mu_ac mean of activity center
#' @param mus list of matrices
#' @param days list of vectors indexing days in master ice array, M
#' @param ms list of matrices with 2 columns. Each matrix gives the pre-computed closest locations on the ice boundary to the true location on the previous day.
#' @param sigsq_mu 
#' @param tausq 
#' @param ps vector of \code{n_sub_pops} probabilities corresponding to each class (should sum to 1).
#' @param mu_acs means of activity centers provided as matrix with two rows (easting, northing).
#' @param Prec_acs precision matrices associated with activity centers given as array with dimensions \code{2, 2, n_sub_pops}.
#' @param prior_params Inverse-gamma distribution prior parameters
#' @param cl default is \code{NULL}, but a cluster may be passed for parallel computation
#' @return scalar
#' @export
get_ld_fc_mu_ac <- function(mu_ac, sub_pop, mus, days, ms = NULL, sigsq_mu, tausq, summer, 
                            ps, mu_acs, Prec_acs, prior_params, cl = NULL){
  mu_acs[, sub_pop + 1] <- mu_ac
  if(is.null(cl)){
    sum(sapply(1:length(mus), function(i){
      get_ld_mu(mu = mus[[i]], sigsq_mu = sigsq_mu, 
                m = ms[[i]], days = days[[i]], tausq = tausq, summer = summer, 
                ps = ps[i], mu_acs = mu_acs, Prec_acs = Prec_acs)  
    })) + mvnfast::dmvn(mu_ac, mu = prior_params[1:2], 
                        sigma = matrix(prior_params[3:6], 2, 2), log = T)
  } else {
    sum(parallel::parSapply(cl = cl, 1:length(mus), function(i){
      get_ld_mu(mu = mus[[i]], sigsq_mu = sigsq_mu, 
                m = ms[[i]], days = days[[i]], tausq = tausq, summer = summer, 
                ps = ps[i], mu_acs = mu_acs, Prec_acs = Prec_acs)  
    })) + mvnfast::dmvn(mu_ac, mu = prior_params[1:2], 
                        sigma = matrix(prior_params[3:6], 2, 2), log = T)
  }
}

#' Compute the log density of \code{summer_range}.
#' 
#' @param summer_range ordered 2-vector
#' @param mus list of matrices
#' @param days list of vectors indexing days in master ice array, M
#' @param ms list of matrices with 2 columns. Each matrix gives the pre-computed closest locations on the ice boundary to the true location on the previous day.
#' @param sigsq_mu 
#' @param tausq 
#' @param ps vector of \code{n_sub_pops} probabilities corresponding to each class (should sum to 1).
#' @param mu_acs means of activity centers provided as matrix with two rows (easting, northing).
#' @param Prec_acs precision matrices associated with activity centers given as array with dimensions \code{2, 2, n_sub_pops}.
#' @param prior_params Inverse-gamma distribution prior parameters
#' @param day_1 time in class \code{POSIXct()}
#' @param day_last time in class \code{POSIXct()}
#' @param cl default is \code{NULL}, but a cluster may be passed for parallel computation
#'
#' @return scalar
#' @export
get_ld_fc_summer <- function(summer_range, day_1, day_last, mus, days, ms = NULL, sigsq_mu, tausq, 
                             ps, mu_acs, Prec_acs, prior_params, cl = NULL){
  if(min(summer_range) < 0 || max(summer_range) > 365*2 || min(summer_range) > max(summer_range)){
    return(-Inf)
  }
  summer <- make_summer(summer_range = summer_range, day_1 = day_1, day_last = day_last)
  if(is.null(cl)){
    sum(sapply(1:length(mus), function(i){
      get_ld_mu(mu = mus[[i]], sigsq_mu = sigsq_mu, 
                m = ms[[i]], days = days[[i]], tausq = tausq, summer = summer, 
                ps = ps[i], mu_acs = mu_acs, Prec_acs = Prec_acs)  
    })) + mvnfast::dmvn(summer_range, mu = prior_params[1:2], 
                        sigma = matrix(prior_params[3:6], 2, 2), log = T)
  } else {
    sum(parallel::parSapply(cl = cl, 1:length(mus), function(i){
      get_ld_mu(mu = mus[[i]], sigsq_mu = sigsq_mu, 
                m = ms[[i]], days = days[[i]], tausq = tausq, summer = summer, 
                ps = ps[i], mu_acs = mu_acs, Prec_acs = Prec_acs)  
    })) + mvnfast::dmvn(summer_range, mu = prior_params[1:2], 
                        sigma = matrix(prior_params[3:6], 2, 2), log = T)
  }
}

#' Compute the log density of \code{p[i, ]}.
#' 
#' @param p_i vector of length \code{n_sub_pops - 1}. For now, I assume \code{n_sub_pops} is 2 so this is a scalar. Code must be altered for general case.
#' @param mu matrix with 2 columns
#' @param days list of vectors indexing days in master ice array, M
#' @param m matrix with 2 columns giving the pre-computed closest locations on the ice boundary to the true location on the previous day.
#' @param sigsq_mu 
#' @param tausq 
#' @param mu_acs means of activity centers provided as matrix with two rows (easting, northing).
#' @param Prec_acs precision matrices associated with activity centers given as array with dimensions \code{2, 2, n_sub_pops}.
#' @param prior_params Inverse-gamma distribution prior parameters
#' @param cl default is \code{NULL}, but a cluster may be passed for parallel computation
#'
#' @return scalar
#' @export
get_ld_fc_p_i <- function(p_i, mu, days_i, m = NULL, sigsq_mu, tausq, summer,
                          mu_acs, Prec_acs, prior_params){
  if(sum(p_i) <= 0 || sum(p_i) >= 1){
    return(-Inf)
  }
  get_ld_mu(mu = mu, sigsq_mu = sigsq_mu, m = m, 
            days = days_i, tausq = tausq, summer = summer, 
            ps = p_i, mu_acs = mu_acs, Prec_acs = Prec_acs) + 
    log(p_i) * (prior_params[1] - 1) + log(1 - p_i) * (prior_params[2] - 1)
}

#' Fit the Ice Boundary model to data using MCMC w/Metropolis updates..
#'
#' @param N_iterations 
#' @param data 
#' @param initial_values 
#' @param prior_params 
#' @param fixed_params 
#' @param tuning_params_init 
#' @param tuning_covs_init 
#' @param exact_ice logical. Should the exact likelihood be used? Requires evaluation of computationally demanding integral.
#' @param rel_tol for integral calculation (normalizing constant). Passed to \code{R2Cuba::divonne()}.
#' @param batch_size 
#' @param save_out_file 
#' @param save_out_rate 
#' @param exact_ice 
#' @param rel_tol 
#' @param seed 
#' @param verbose 
#'
#' @return lots of stuff
#' @export
abr_mcmc <- function(N_iterations = 1e2, 
                     data, initial_values, prior_params, fixed_params, 
                     tuning_params_init = NULL, tuning_params_fixed = NULL,
                     batch_size = min(30, N_iterations), 
                     save_out_file = NULL, save_out_rate = 100, 
                     seed = NULL, verbose = F, ncores = 1){
  if(!is.null(seed)){
    set.seed(seed)
  }
  ## variables 
  n_indiv <- length(data$mus)
  ## timing
  timing <- rep(0, 6); cur_time <- Sys.time()
  timing_chkpt <- max(1, floor(N_iterations / 20))
  init_time <- Sys.time()
  ## save out 
  if(is.null(save_out_file)){
    save_out_file <- paste(format(init_time, "%Y%m%d_%H%M%S"), "abr_fit.RData", sep = "")
  }
  ## parameter storage
  chains <- lapply(initial_values, function(param){
    if(length(param) == 1){
      return(c(param, rep(NA, N_iterations)))
    } else if(is.null(dim(param))){
      return(cbind(as.numeric(param), matrix(NA, length(param), N_iterations)))
    } else {
      return(array(c(param, rep(NA, prod(dim(param))*N_iterations)), 
                   dim = c(dim(param), N_iterations + 1)))
    }
  })
  if(is.null(dim(chains$ps))){
    chains$ps <- matrix(chains$ps, nrow = 1)
  }
  ## define summer
  summer <- make_summer(summer_range = initial_values$summer_range, 
                        day_1 = data$day_1, day_last = data$day_last)
  ## update the cholesky of Prec_ac, not the precision matrix, to ensure proposals are SPD
  if(is.null(dim(chains$eigen_acs))){
    chains$eigen_acs <- array(apply(chains$Prec_acs[, , , 1], 3, function(x){
      eigen_x <- eigen(x)
      c(sqrt(eigen_x$values), acos(eigen_x$vectors[2, 1]))
    }), 
    dim = c(3, 2, N_iterations + 1))
    chains$eigen_acs[, , -1] <- NA
  }
  if(is.null(dim(chains$Prec_acs))){
    chains$Prec_acs <- array(
      apply(chains$eigen_acs[, , 1], 2, function(x){
        d <- (x[1:2])^2
        U <- matrix(c(cos(x[3]), sin(x[3]), -sin(x[3]), cos(x[3])), 2, 2)
        Prec_ac <- U %*% (1/d * t(U))
      }), dim = c(2, 2, 2, N_iterations + 1))
    chains$Prec_acs[, , , -1] <- NA
  }
  chains$k <- matrix(NA, n_indiv, N_iterations + 1)
  chains$ld_mus <- matrix(NA, 2 + 1 + n_indiv + 2 + 2, N_iterations + 1)
  ## tuning parameters
  tuning_params <- 
    lapply(initial_values[which(!names(initial_values) %in% c('ps'))], 
           function(param){
             out <- matrix(1, 2, floor(N_iterations/batch_size) + 1)
             if(is.null(dim(param))){
               out <- array(param, dim = floor(N_iterations/batch_size) + 1)
             }
             return(out)
           })
  tuning_params$ps <- array(initial_values$ps, dim = c(length(initial_values$ps), floor(N_iterations/batch_size) + 1))
  if("ps" %in% names(tuning_params_init)){
    tuning_params$ps <- array(tuning_params_init$ps, dim = c(length(initial_values$ps), floor(N_iterations/batch_size) + 1))
  }
  tuning_covs <- 
    lapply(initial_values[which(!names(initial_values) %in% c('ps'))], 
           function(param){
             out <- NA
             if(!is.null(dim(param))){
               dim_param <- dim(param)
               param. <- matrix(param, prod(dim_param[-length(dim_param)]), dim_param[length(dim_param)])
               out <- array(apply(param., 2, function(x) diag(rep(1, length(x)))), 
                            dim = c(rep(dim(param.)[1], 2), dim_param[2], floor(N_iterations/batch_size) + 1))
             }
             if(is.null(dim(param)) & length(param) > 1){
               out <- array(diag(rep(1, length(param))), 
                            dim = c(rep(length(param), 2), floor(N_iterations/batch_size) + 1))
             }
             return(out)
           })
  tuning_covs$ps <- NA
  for(param_name in names(tuning_params)[which(!names(initial_values) %in% c('ps'))]){
    if(param_name %in% names(tuning_params_init) & !is.null(tuning_params_init[param_name])){
      tuning_params[[param_name]][1:length(tuning_params_init[[param_name]])] <- tuning_params_init[[param_name]]
    }
  }
  for(param_name in names(tuning_covs)[which(!names(initial_values) %in% c('ps'))]){
    if(param_name %in% names(tuning_covs_init) & !is.null(tuning_covs_init[param_name])){
      tuning_covs[[param_name]][1:length(tuning_covs_init[[param_name]])] <- tuning_covs_init[[param_name]]
    }
  }
  batch_no <- 1
  ## process imputation 
  if(is.null(data$K)){
    data$K <- 1
    if(!is.list(data$mus[[1]])){
      data$mus <- sapply(1:n_indiv, function(i){(data$mus[i])}, simplify = F)
    }
    if(!is.list(data$ms[[1]])){
      data$ms <- sapply(1:n_indiv, function(i){(data$ms[i])}, simplify = F)
    }
  }
  ## parallelization (across individuals)
  cl <- NULL
  if(ncores > 1){
    cl <- parallel::makeForkCluster(ncores)
  }
  ## MCMC loop
  for(iter in 1 + 1:N_iterations){
    ## selection from imputed paths ----
    k <- sample(1:data$K, size = n_indiv, replace = T)
    chains$k[, iter] <- k
    mus_iter <- sapply(1:n_indiv, function(i) data$mus[[i]][[k[i]]], simplify = F)
    ms_iter <- sapply(1:n_indiv, function(i) data$ms[[i]][[k[i]]], simplify = F)
    ## get initial likelihood after choosing paths ----
    if(is.null(cl)){
      ld_mus <- sum(
        sapply(1:length(mus_iter), function(i){
          get_ld_mu(mu = mus_iter[[i]], sigsq_mu = chains$sigsq_mu[iter - 1], 
                    m = ms_iter[[i]], days = days[[i]], tausq = chains$tausq[iter - 1], 
                    summer = summer, ps = chains$ps[i, iter - 1], mu_acs = chains$mu_acs[, , iter - 1], 
                    Prec_acs = chains$Prec_acs[, , , iter - 1])  
        }))
    } else {
      parallel::clusterExport(cl, c("mus_iter", "ms_iter", "iter"), environment())
      ld_mus <- sum(parallel::parSapply(cl = cl, 1:length(mus_iter), function(i){
        get_ld_mu(mu = mus_iter[[i]], sigsq_mu = chains$sigsq_mu[iter - 1],
                  m = ms_iter[[i]], days = days[[i]], tausq = chains$tausq[iter - 1],
                  summer = summer, ps = chains$ps[i, iter - 1], mu_acs = chains$mu_acs[, , iter - 1],
                  Prec_acs = chains$Prec_acs[, , , iter - 1])
      }))
    }
    if(!is.null(cl)) parallel::clusterExport(cl, c("mus_iter", "ms_iter", "iter"), environment())
    if(verbose) message("ld_mus at start of iteration =", ld_mus)
    ## sigsq_mu ----
    chains$sigsq_mu[iter] <- chains$sigsq_mu[iter - 1]
    if(!fixed_params$sigsq_mu){
      ld_fc_prev <- ld_mus - (prior_params$sigsq_mu[1] + 1) * log(chains$sigsq_mu[iter - 1]) - 
        prior_params$sigsq_mu[2] / chains$sigsq_mu[iter - 1]
      if(!is.null(cl)) parallel::clusterExport(cl, c("ld_fc_prev"), environment())
      sigsq_mu_draw <- sample_rw(prev = chains$sigsq_mu[iter - 1], 
                                 tune = tuning_params$sigsq_mu[batch_no], 
                                 get_ld_fc = get_ld_fc_sigsq_mu, ld_fc_prev = ld_fc_prev, 
                                 mus = mus_iter, days = data$days, ms = ms_iter, 
                                 tausq = chains$tausq[iter - 1], summer = summer,
                                 mu_acs = chains$mu_acs[, , iter - 1], 
                                 Prec_acs = chains$Prec_acs[, , , iter - 1], ps = chains$ps[, iter - 1], 
                                 prior_params = prior_params$sigsq_mu, cl = cl, verbose = verbose)
      chains$sigsq_mu[iter] <- sigsq_mu_draw$draw
      ld_mus <- sigsq_mu_draw$ld_fc + (prior_params$sigsq_mu[1] + 1) * log(chains$sigsq_mu[iter]) + 
        prior_params$sigsq_mu[2] / chains$sigsq_mu[iter]
      chains$ld_mus[1, iter] <- ld_mus
    }
    ## tausq ----
    chains$tausq[iter] <- chains$tausq[iter - 1]
    if(!fixed_params$tausq){
      ld_fc_prev <- ld_mus - (prior_params$tausq[1] + 1) * log(chains$tausq[iter - 1]) - 
        prior_params$tausq[2] / chains$tausq[iter - 1]
      if(!is.null(cl)) parallel::clusterExport(cl, c("chains", "ld_fc_prev"), environment())
      tausq_draw <- sample_rw(prev = chains$tausq[iter - 1], tune = tuning_params$tausq[batch_no], 
                              get_ld_fc = get_ld_fc_tausq, ld_fc_prev = ld_fc_prev, summer = summer,
                              mus = mus_iter, days = data$days, ms = ms_iter, 
                              sigsq_mu = chains$sigsq_mu[iter], mu_acs = chains$mu_acs[, , iter - 1], 
                              Prec_acs = chains$Prec_acs[, , , iter - 1], ps = chains$ps[, iter - 1], 
                              prior_params = prior_params$tausq, cl = cl, verbose = verbose)
      chains$tausq[iter] <- tausq_draw$draw
      ld_mus <- tausq_draw$ld_fc + (prior_params$tausq[1] + 1) * log(chains$tausq[iter]) +
        prior_params$tausq[2] / chains$tausq[iter]
      chains$ld_mus[2, iter] <- ld_mus
    }
    ## summer_range ----
    chains$summer_range[, iter] <- chains$summer_range[, iter - 1]
    if(!fixed_params$summer_range){
      ld_fc_prev <- ld_mus + mvnfast::dmvn(chains$summer_range[, iter - 1], mu = prior_params$summer_range[1:2], 
                                           sigma = matrix(prior_params$summer_range[3:6], 2, 2), log = T)
      if(!is.null(cl)) parallel::clusterExport(cl, c("chains", "ld_fc_prev"), environment())
      summer_draw <- 
        sample_RW(prev = chains$summer_range[, iter - 1], 
                  tune_cov = tuning_params$summer_range[batch_no] * 
                    tuning_covs$summer_range[, , batch_no], 
                  get_ld_fc = get_ld_fc_summer, ld_fc_prev = ld_fc_prev, 
                  day_1 = data$day_1, day_last = data$day_last,
                  mus = mus_iter, days = data$days, ms = ms_iter, 
                  sigsq_mu = chains$sigsq_mu[iter], 
                  tausq = chains$tausq[iter], mu_acs = chains$mu_acs[, , iter - 1],
                  Prec_acs = chains$Prec_acs[, , , iter - 1], ps = chains$ps[, iter - 1],
                  prior_params = prior_params$summer_range, cl = cl, verbose_sampler = verbose)
      chains$summer_range[, iter] <- summer_draw$draw
      ld_mus <- summer_draw$ld_fc - mvnfast::dmvn(chains$summer_range[, iter], mu = prior_params$summer_range[1:2], 
                                                  sigma = matrix(prior_params$summer_range[3:6], 2, 2), log = T)
      chains$ld_mus[2 + 1, iter] <- ld_mus
      summer <- make_summer(chains$summer_range[, iter], day_1 = data$day_1, day_last = data$day_last)
    }
    ## ps ----
    chains$ps[, iter] <- chains$ps[, iter - 1]
    ld_fc_prev <- NULL ## not sure how to keep track of all these
    if(!fixed_params$ps){
      if(!is.null(cl)){
        parallel::clusterExport(cl, c("chains", "ld_fc_prev"), environment())
        chains$ps[, iter] <- parallel::parSapply(cl = cl, X = 1:n_indiv, FUN = function(i){
          sample_rw(prev = chains$ps[i, iter - 1], tune = tuning_params$ps[i, batch_no], 
                    get_ld_fc = get_ld_fc_p_i, ld_fc_prev = ld_fc_prev, summer = summer,
                    mu = mus_iter[[i]], days = data$days[[i]], m = ms_iter[[i]], 
                    sigsq_mu = chains$sigsq_mu[iter], tausq = chains$tausq[iter], 
                    mu_acs = chains$mu_acs[, , iter - 1], Prec_acs = chains$Prec_acs[, , , iter - 1], 
                    prior_params = prior_params$ps, verbose = verbose)$draw
        })
      } else {
          chains$ps[, iter] <- sapply(1:n_indiv, function(i){
          sample_rw(prev = chains$ps[i, iter - 1], tune = tuning_params$ps[i, batch_no], 
                    get_ld_fc = get_ld_fc_p_i, ld_fc_prev = ld_fc_prev, summer = summer,
                    mu = mus_iter[[i]], days = data$days[[i]], m = ms_iter[[i]], 
                    sigsq_mu = chains$sigsq_mu[iter], tausq = chains$tausq[iter], 
                    mu_acs = chains$mu_acs[, , iter - 1], Prec_acs = chains$Prec_acs[, , , iter - 1], 
                    prior_params = prior_params$ps, verbose = verbose)$draw
        })
      }
    }
    ## mu_acs ----
    chains$mu_acs[, , iter] <- chains$mu_acs[, , iter - 1]
    for(sub_pop in 0:1){
      if(!fixed_params$mu_acs){
        if(sub_pop %in% 0:1){
          ld_fc_prev <- NULL ## lost track in ps above
        } else {
          ld_fc_prev <- ld_mus + mvnfast::dmvn(chains$mu_acs[, sub_pop + 1, iter - 1], mu = prior_params$mu_acs[1:2, sub_pop + 1], 
                                                  sigma = matrix(prior_params$mu_acs[3:6, sub_pop + 1], 2, 2), log = T)
        }  
        if(!is.null(cl)) parallel::clusterExport(cl, c("sub_pop", "chains", "ld_fc_prev"), environment())
        mu_ac_draw <- 
          sample_RW(prev = chains$mu_acs[, sub_pop + 1, iter - 1], 
                    tune_cov = tuning_params$mu_acs[sub_pop + 1, batch_no] * 
                      tuning_covs$mu_acs[, , sub_pop + 1, batch_no], 
                    get_ld_fc = get_ld_fc_mu_ac, ld_fc_prev = ld_fc_prev, sub_pop = sub_pop,
                    mus = mus_iter, days = data$days, ms = ms_iter, 
                    sigsq_mu = chains$sigsq_mu[iter], tausq = chains$tausq[iter], 
                    summer = summer, ps = chains$ps[, iter],
                    mu_acs = chains$mu_acs[, , iter], Prec_acs = chains$Prec_acs[, , , iter - 1],
                    prior_params = prior_params$mu_acs[, sub_pop + 1], cl = cl, verbose_sampler = verbose)
        chains$mu_acs[, sub_pop + 1, iter] <- mu_ac_draw$draw
        ld_mus <- mu_ac_draw$ld_fc - mvnfast::dmvn(chains$mu_acs[, sub_pop + 1, iter], mu = prior_params$mu_acs[1:2, sub_pop + 1], 
                                                   sigma = matrix(prior_params$mu_acs[3:6, sub_pop + 1], 2, 2), log = T)
        chains$ld_mus[2 + 1 + n_indiv + sub_pop + 1, iter] <- ld_mus
      }
    }
    ## Prec_acs ----
    chains$Prec_acs[, , , iter] <- chains$Prec_acs[, , , iter - 1]
    chains$eigen_acs[, , iter] <- chains$eigen_acs[, , iter - 1]
    for(sub_pop in 0:1){
      if(!fixed_params$Prec_acs){
        ld_fc_prev <- ld_mus + prior_params$Sigma_acs[[sub_pop + 1]][1] * log(prod(chains$eigen_acs[1:2, sub_pop + 1, iter - 1])) - 
          prior_params$Sigma_acs[[sub_pop + 1]][2] * sum(chains$eigen_acs[1:2, sub_pop + 1, iter - 1])
        if(!is.null(cl)) parallel::clusterExport(cl, c("sub_pop", "chains", "ld_fc_prev"), environment())
        eigen_ac_draw <- 
          sample_RW(prev = chains$eigen_acs[, sub_pop + 1, iter - 1], 
                    tune_cov = tuning_params$eigen_acs[sub_pop + 1, batch_no] * 
                      tuning_covs$eigen_acs[, , sub_pop + 1, batch_no], 
                    get_ld_fc = get_ld_fc_Sigma_ac, ld_fc_prev = ld_fc_prev, sub_pop = sub_pop,
                    mus = mus_iter, days = data$days, ms = ms_iter, 
                    sigsq_mu = chains$sigsq_mu[iter], tausq = chains$tausq[iter], summer = summer,
                    ps = chains$ps[, iter], mu_acs = chains$mu_acs[, , iter],
                    Prec_acs = chains$Prec_acs[, , , iter],
                    prior_params = prior_params$Sigma_acs[[sub_pop + 1]], cl = cl, verbose_sampler = verbose)
        chains$eigen_acs[, sub_pop + 1, iter] <- eigen_ac_draw$draw
        ld_mus <- eigen_ac_draw$ld_fc - prior_params$Sigma_acs[[sub_pop + 1]][1] * log(prod(chains$eigen_acs[1:2, sub_pop + 1, iter])) + 
          prior_params$Sigma_acs[[sub_pop + 1]][2] * sum(chains$eigen_acs[1:2, sub_pop + 1, iter])
        chains$ld_mus[2 + 1 + n_indiv + 2 + sub_pop + 1, iter] <- ld_mus
        if(diff(chains$eigen_acs[1, sub_pop + 1, c(iter - 1, iter)]) != 0){
          d <- (eigen_ac_draw$draw[1:2])^2
          U <- matrix(c(cos(eigen_ac_draw$draw[3]), sin(eigen_ac_draw$draw[3]), 
                        -sin(eigen_ac_draw$draw[3]), cos(eigen_ac_draw$draw[3])), 2, 2)
          chains$Prec_acs[, , sub_pop + 1, iter] <- U %*% (1/d * t(U))
        }
      }
    }
    ## tuning ----
    if(iter %% batch_size == 1){
      batch_no = batch_no + 1
      for(param in names(tuning_params)){
        if(fixed_params[[param]]){
          tuning_params[[param]][batch_no] <- tuning_params[[param]][batch_no - 1]
        } else {
          if(is.na(tuning_covs[param])){
            if(param %in% tuning_params_fixed){
              tuning_params[[param]][batch_no] <- tuning_params[[param]][batch_no - 1]
            } else {
              if(class(tuning_params[[param]]) == "matrix"){
                tuning_params[[param]][, batch_no] <- sapply(1:nrow(chains[[param]]), function(i){
                  update_tuning(batch = chains[[param]][i, (iter - batch_size):iter], 
                                batch_no = batch_no, tuning_param = tuning_params[[param]][i, batch_no - 1])
                })
              } else {
              tuning_params[[param]][batch_no] <- 
                update_tuning(batch = chains[[param]][(iter - batch_size):iter], 
                              batch_no = batch_no, tuning_param = tuning_params[[param]][batch_no - 1])
              }
            }
          } else {
            if(length(dim(chains[[param]])) == 2){
              tuning_update_stuff <- 
                update_TUNING(batch = matrix(chains[[param]][, (iter - batch_size):iter], ncol = batch_size + 1),
                              batch_no = batch_no, tuning_param = tuning_params[[param]][batch_no - 1], 
                              tune_cov = tuning_covs[[param]][, , batch_no - 1])
              tuning_covs[[param]][, , batch_no] <- tuning_update_stuff$tune_cov
              tuning_params[[param]][batch_no] <- tuning_update_stuff$param
              if(param %in% tuning_params_fixed){
                tuning_params[[param]][batch_no] <- tuning_params[[param]][batch_no - 1]
              } else {
                tuning_params[[param]][batch_no] <- tuning_update_stuff$param
              }
            } else if(length(dim(chains[[param]])) == 3){
              for(sub_param in 1:dim(tuning_covs[[param]])[3]){
                tuning_update_stuff <- 
                  update_TUNING(batch = matrix(chains[[param]][, sub_param, (iter - batch_size):iter], 
                                               ncol = batch_size + 1),
                                batch_no = batch_no, tuning_param = tuning_params[[param]][sub_param, batch_no - 1], 
                                tune_cov = tuning_covs[[param]][, , sub_param, batch_no - 1])
                tuning_covs[[param]][, , sub_param, batch_no] <- tuning_update_stuff$tune_cov
                if(param %in% tuning_params_fixed){
                  tuning_params[[param]][sub_param, batch_no] <- tuning_params[[param]][sub_param, batch_no - 1]
                } else {
                  tuning_params[[param]][sub_param, batch_no] <- tuning_update_stuff$param
                }
              } 
            } else if(length(dim(chains[[param]])) == 4){
              for(sub_param in 1:dim(tuning_covs[[param]])[3]){
                tuning_update_stuff <- 
                  update_TUNING(batch = matrix(chains[[param]][, , sub_param, (iter - batch_size):iter], 
                                               ncol = batch_size + 1),
                                batch_no = batch_no, tuning_param = tuning_params[[param]][sub_param, batch_no - 1], 
                                tune_cov = tuning_covs[[param]][, , sub_param, batch_no - 1])
                tuning_covs[[param]][, , sub_param, batch_no] <- tuning_update_stuff$tune_cov
                if(param %in% tuning_params_fixed){
                  tuning_params[[param]][sub_param, batch_no] <- tuning_params[[param]][sub_param, batch_no - 1]
                } else {
                  tuning_params[[param]][sub_param, batch_no] <- tuning_update_stuff$param
                }
              }
            }
          }
        }
      }
      if(!is.null(cl)) parallel::clusterExport(cl, c("tuning_params", "tuning_covs", "batch_no"), environment())
    }
    ## timing ----
    if(iter %% timing_chkpt == 1){
      timing <- Sys.time() - init_time
      message(paste("iteration ", iter-1, " (", floor((iter-1)/N_iterations*100), "%)",
                    " [", signif(timing, 5), " ", attr(timing, "units"), "]", sep = ""))
    }
    if(verbose) message("iteration, ", iter-1)
    ## save out ----
    if(iter %% save_out_rate == 1 & iter < N_iterations + 1){
      out <- list("N_iterations" = N_iterations, "initial_values" = initial_values,
                  "fixed_params" = fixed_params, "prior_params" = prior_params, "data" = data,
                  "tuning_params" = tuning_params, "tuning_covs" = tuning_covs, "timing" = timing,
                  "chains" = chains)
      save(out, file = save_out_file)
    }
  }
  ## stop cluster
  if(!is.null(cl)) parallel::stopCluster(cl)
  out <- list("N_iterations" = N_iterations, "initial_values" = initial_values,
              "fixed_params" = fixed_params, "prior_params" = prior_params, "data" = data,
              "tuning_params" = tuning_params, "tuning_covs" = tuning_covs, "timing" = timing,
              "chains" = chains)
  return(out)
}
