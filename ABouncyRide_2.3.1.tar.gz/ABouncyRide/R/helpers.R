#' Get Boundary Conic 
#' 
#' Function to find the surface representing a constant ratio between two bivariate Gaussian distributions. This uses functions from the conics package that have been slightly modified.
#'
#' @param mu two-column matrix where each column is a mean
#' @param Sigma three-dimensional array where each matrix is a covariance matrix
#' @param level log of ratio between two normal distributions
#' @param plot_boundary logical
#' @param ... passed to \code{conicPlot()}
#'
#' @return output of call to \code{conicPlot()}
#' @export
get_boundary_conic <- function(mu, Sigma = NULL, Prec = NULL, level = 0, plot_boundary = T, 
                               npoints = 100, add = T, ...){
  if(is.null(Sigma)){
    if(is.null(Prec)){
      stop("Must provide either Sigma or Prec.")
    }
    Sigma <- array(apply(Prec, 3, solve), dim = dim(Prec))
  }
  if(is.null(Prec)){
    Prec <- array(apply(Sigma, 3, solve), dim = dim(Sigma))
  }
  ## Precs are equal ----
  if(identical(Prec[, , 1], Prec[, , 2])){
    C <- 0.5 * (mu[, 1] - mu[, 2]) %*% Prec[, , 1] %*% (mu[, 1] - mu[, 2])
    AB <- Prec[, , 1] %*% (mu[, 1] - mu[, 2])
    if(plot_boundary) abline(a = C / AB[2], b = AB[1] / AB[2], ...)
    return(c(AB, C))
  } 
  ## Precs unequal ----
  else {
    A <- Prec[, , 1] - Prec[, , 2]
    b <- Prec[, , 1] %*% mu[, 1] - Prec[, , 2] %*% mu[, 2]
    c <- determinant(Sigma[, , 1])$modulus - determinant(Sigma[, , 2])$modulus +
      mu[, 1] %*% Prec[, , 1] %*% mu[, 1] - mu[, 2] %*% Prec[, , 2] %*% mu[, 2]
    v <- c(A[1, 1], 2*A[1, 2], A[2, 2], -2*b, c + 2*level)
    m <- conicMatrix(v)
    if(plot_boundary){
      conic <- conicPlot(m, npoints = npoints, add = add, ...)
    } else {
      conic <- conicPlot(m, npoints = npoints, add = add, type = "n", ...)
    }
    conic$m <- m
    return(conic)
  }
}
