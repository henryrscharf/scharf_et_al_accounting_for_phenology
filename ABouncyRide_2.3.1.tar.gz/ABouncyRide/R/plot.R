#' Plot an ice simulation
#'
#' @param ice_simulation object resulting from call to \code{simulate.ice_model()}.
#'
#' @return NULL
plot.ice_simulation <- function(ice_simulation, col = "viridis", ...){
  par(mar = c(2.1, 2.1, 2.1, 2.1))
  if(col == "viridis"){
    ice.colors <- viridis::viridis(length(ice_simulation[['times']]))
    legend.colors <- rev(viridis::viridis(12))
  } else if(col == "gray"){
    ice.colors <- gray.colors(length(ice_simulation[['times']]))
    legend.colors <- rev(gray.colors(12))
  }
  matplot(ice_simulation[['longitudes']], ice_simulation[['latitudes']], type  = "l", 
          col = ice.colors, lty = 1,
          xlab = "", ylab = "", bty = "n", axes = F, ...)
  mtext("easting", 1, line = -1); mtext("northing", 2, line = -1)
  legend(x = par()$usr[2]*0.98, y = mean(par()$usr[3:4]), col = legend.colors, pch = 15, pt.cex = 2, horiz = F,
         legend = rev(floor(seq(1, length(ice_simulation[['times']]), l=12))) * c(1, rep(NA, 10), 1), 
         bty = "n", title = "Day", xpd = T, yjust = 0.5)
  return(NULL)
}

#' Plot a path simulation
#'
#' @param abr_simulation object resulting from call to \code{simulate.abr_model()}.
#'
#' @return NULL
#' @export
plot.abr_simulation <- function(abr_simulation, incl.mean = T, incl.mu_til = T, incl.m = T, 
                                incl.mu_activity = T, ice.col = "viridis"){
  list2env(abr_simulation, envir = environment())
  TIME <- length(ice[["times"]])
  plot(ice, col = ice.col)
  if(incl.mu_activity){
    points(t(mu_activity), cex = 1.5, lwd = 2, pch = 17, col = scales::muted("red"))
  }
  if(incl.m){
    points(m, lwd = 2, pch = 22, cex = 1, bg = "white", col = viridis::viridis(TIME))
  }
  if(incl.mu_til){
    points(mu.til, lwd = 2, pch = 24, cex = 1, bg = "white", col = viridis::viridis(TIME))
  }
  if(incl.m & incl.mu_til){
    segments(x0 = m[, 1], x1 = mu.til[, 1], y0 = m[, 2], y1 = mu.til[, 2],
             col = scales::alpha(1, 0.4), lwd = 3)
  }
  lines(mu, type = "b", pch = 19, cex = 0.5, lwd = 2)
  if(incl.mean){
    points(mean, lwd = 2)
  }
  legend("topleft", pch = c(19, 17), pt.cex = c(0.5, 2), lwd = 2, 
         horiz = F, lty = NA, bty = "n", xpd = T, x.intersp = 1,  
         legend = c("true locations", expression(mu[west])))
  if(incl.mu_til || incl.m || incl.mean){
  legend("topright", pch = c(22, 24, 1), pt.cex = c(1, 1, 1), lwd = 2, 
         horiz = F, lty = NA, bty = "n", xpd = T, x.intersp = 0.1,
         legend = c("nearest location on ice", "ar combination", "mean"))
  }
  return(NULL)
}

#' plot.fit1_crawl
#' Plots the simulated paths from the \code{crawl} model.
#'
#' @param fit1 output from call to fit.mi()
#' @param path path object optionally supplied to plot potential function and true path
#' @param which.plots for now only 1 plot available
#' @param potential.func used to plot potential function
#' @param beta used to plot potential function, default is 1
#' @param ...
#'
#' @return \code{NULL}
#' @export
plot.fit1_crawl <- function(fit1, path = NULL, which.plots = 1, potential.func = NULL,
                            beta = 1, line.col = "black", axes = TRUE, main = "imputed.paths",
                            in.color = TRUE, ...){
  if(1 %in% which.plots){
    ## plot path with imputed paths ----
    # xlimits <- range(lapply(fit1$mu.star, function(x) range(x[, 1])))
    # ylimits <- range(lapply(fit1$mu.star, function(x) range(x[, 2])))
    if(is.null(path)){
      path <- list("s" = fit1$s, "observation.times" = fit1$observation.times)
      if(!is.null(potential.func)){
        path$potential.func <- potential.func
      }
      class(path) <- "path"
    }
    plot(path, main = main, axes = axes, in.color = in.color, ...)
    paths.plotted <- 1:fit1$K
    if(length(paths.plotted) > 5e2){
      paths.plotted <- sample(paths.plotted, 3e2)
    }
    for(iter in paths.plotted){
      lines(fit1$mu.star[[iter]],
            col = alpha(line.col, alpha = max(2e-3, min(1, 7/length(paths.plotted)))))
    }
    if(!is.null(path$r)){
      lines(path$r, col = muted("red"), lwd = 2, lty = 2)
    }
    points(path$s, pch = 16, cex = 0.5)
    if(in.color){
      points(t(path$s[1, ]), pch = 16, col = scales::muted("green"), cex = 1.5)
      points(t(path$s[dim(path$s)[1], ]), pch = 17, col = scales::muted("red"), cex = 1.5)
    } else {
      points(t(path$s[1, ]), pch = 16, cex = 1.5)
      points(t(path$s[dim(path$s)[1], ]), pch = 17, cex = 1.5)
    }
  }
}