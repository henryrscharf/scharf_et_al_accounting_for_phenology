#' Telemetry observations of polar bear trajectories 2012--2016
#'
#' A dataset gathered by the USFWS and USGS containing the locations of 186 polar bears. Accessed using \code{data('pb_2012_2016')}.
#'
#' @format A data frame called \code{pb} with 316626 rows and 11 variables:
#' \describe{
#'   \item{animal}{individual id}
#'   \item{POSIX}{time of observation}
#'   \item{latitude}{latitude of observation}
#'   \item{longitud}{longitude of observation}
#'   \item{lc94}{ARGOS location class}
#'   \item{Loctype}{type of observation (either Argos or GPS/Iridium)}
#'   \item{Sex}{sex of individual}
#'   \item{Source}{agency that gathered observation}
#'   \item{Semi.major.axis}{ARGOS-reported error ellipse major axis length}
#'   \item{Semi.minor.axis}{ARGOS-reported error ellipse minor axis length}
#'   \item{Ellipse.orientation}{ARGOS-reported error ellipse orientation angle}
#' }
"pb"

#' 50 meter resolution coastline
#'
#' Object of class \code{SpatialPolygonsDataFrame} giving 50 meter resolution coastline. Accessed using \code{data('land')}.
"land"

#' Stage 1 polar bear trajectories
#'
#' Trajectories simulated from the stage 1 imputation distribution. Accessed using \code{data('stage1_paths')}.
#'
#' @format A list containing trajectory imputations accounting for measurement error for each polar bear. Each entry is a list with elements. Also a character string, \code{bad_ids}, which gives the animal ids of any problematic individuals from stage 1 model fitting/simulating.
#' \describe{
#'   \item{K_crawl}{number of imputations}
#'   \item{interp.times}{days on which trjaectory imputations were realized}
#'   \item{basis_func}{character string giving information about imputation modle}
#'   \item{mu.star}{list of length \code{K_crawl}; each element is a 2-column matrices giving trajectory locations for each imputation}
#'   \item{s}{observed locations}
#'   \item{observation_times}{times at which observations were made}
#'   \item{fit1_crawl}{fit information from \code{crawl}}
#'   \item{id}{individual id}
#'   \item{source}{agency that gathered observation}
#' }
"mu_stars"

#' Pre-computed ms for stage 1 polar bear trajectories
#'
#' Values of \eqn{\mathbf{m}_i(t)} for each individual \eqn{i} and day \eqn{t} for each imputed trajectory. Accessed using \code{data('stage1_ms')}.
#'
#' @format A list containing \eqn{\mathbf{m}} for each polar bear. Each entry is a list with \code{K_crawl} 2-column matrices.
"ms"

#' Stage 2 model fit
#'
#' List giving output from a call to the function \code{abr_fit()} for the polar bear data. Accessed using \code{data('stage2_fit')}.
#'
#' @format List with elements:
#' \describe{
#'   \item{N_iterations}{number of iterations used in MCMC algorithm}
#'   \item{initial_values}{initial values used in MCMC algorithm}
#'   \item{fixed_params}{fixed parameters in MCMC algorithm}
#'   \item{prior_params}{parameters used to specify prior distributions}
#'   \item{data}{stage 1 trajectories and \eqn{\mathbf{m}} used in likelihood}
#'   \item{tuning_params}{log of adaptively-chosen tuning parameters used for MH updates}
#'   \item{tuning_covs}{log of adaptively-chosen tuning covariances used for block/multivariate MH updates}
#'   \item{timing}{take taken to execute MCMC algorithm}
#'   \item{chains}{draws from the MCMC algorithm with stationary solution equal to posterior distribution}
#' }
"abr_fit"