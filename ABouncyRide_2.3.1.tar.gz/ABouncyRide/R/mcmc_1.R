#' Get the log density of s
#'
#' @param sigsq_s 
#' @param sigsq_muos 
#' @param s 
#' @param Sigma_s_inv_list 
#' @param Sigma_s_log_det 
#' @param H 
#'
#' @return list of log density (\code{ld_s}), inverse of C, (\code{C_inv}), and log determinant of C (\code{C_log_det}).
get_ld_s <- function(sigsq_s, sigsq_muos, s, C_inv = NULL, C_log_det = NULL,
                     Sigma_s_inv_list, Sigma_s_log_det, H){
  n <- length(s)
  if(is.null(C_inv)){
    Sigma_s_inv <- Matrix::bdiag(Sigma_s_inv_list)
    H <- sqrt(sigsq_muos) * H
    A <- as.matrix(Sigma_s_inv %*% H)
    B <- t(H) %*% A
    C_inv <- as.matrix(Sigma_s_inv - A %*% solve(diag(ncol(H)) + B) %*% t(A))
  }
  if(is.null(C_log_det)){
    if(!exists("B")){
      Sigma_s_inv <- Matrix::bdiag(Sigma_s_inv_list)
      H <- sqrt(sigsq_muos) * H
      A <- as.matrix(Sigma_s_inv %*% H)
      B <- t(H) %*% A
    }
    C_log_det <- -0.5*(determinant(as.matrix(diag(ncol(H)) + B))$modulus + Sigma_s_log_det)
  }
  ld_s <- C_log_det - 0.5*n*log(sigsq_s) - 0.5 * c(t(s)) %*% C_inv %*% c(t(s)) / sigsq_s
  return(list("ld_s" = as.numeric(ld_s), "C_inv" = C_inv, "C_log_det" = C_log_det))
}

#' Sample measurement variance
#'
#' @param sigsq_s 
#' @param sigsq_muos 
#' @param s 
#' @param C.inv 
#' @param prior_params 
#'
#' @return scalar
sample_sigsq_s <- function(sigsq_s, sigsq_muos, s, C_inv, prior_params){
  1/rgamma(n = 1, shape = prior_params[1] + nrow(s), 
           rate = prior_params[2] + 0.5 * c(t(s)) %*% C_inv %*% c(t(s)))
}

#' Compute the log density of \eqn{\sigma^2_{\mu/s}}.
#'
#' @param sigsq_s 
#' @param sigsq_muos 
#' @param s 
#' @param C_inv 
#' @param C_log_det 
#' @param prior_params 
#'
#' @return list
get_ld_fc_sigsq_muos <- function(sigsq_muos, sigsq_s, s, Sigma_s_inv_list, 
                                 Sigma_s_log_det, H, prior_params){
  if(sigsq_muos <= 0){
    return(list("ld" = 1e-16, "C_inv" = NULL, "C_log_det" = NULL))
  }
  ld_s <- get_ld_s(sigsq_s = sigsq_s, sigsq_muos = sigsq_muos, s = s, 
                   Sigma_s_inv_list = Sigma_s_inv_list, Sigma_s_log_det = Sigma_s_log_det, H = H)
  return(list("ld" = ld_s$ld_s - (prior_params[1] + 1) * log(sigsq_muos) - prior_params[2] / sigsq_muos,
              "C_inv" = ld_s$C_inv, "C_log_det" = ld_s$C_log_det))
}

#' MCMC algorithm for buderman-style movement model
#'
#' @param N_iterations 
#' @param data 
#' @param initial_values 
#' @param prior_params 
#' @param fixed_params 
#' @param batch_size 
#' @param save_out_file 
#' @param save_out_rate 
#'
#' @return list
buderman_mcmc <- function(N_iterations = 1e2,
                          data, initial_values, prior_params, fixed_params,
                          batch_size = min(30, N_iterations),
                          save_out_file = NULL, save_out_rate = 100){
  ## variables
  n_indiv <- length(data$mus)
  ## timing
  timing <- rep(0, 6); cur_time <- Sys.time()
  timing_chkpt <- max(1, floor(N_iterations / 20))
  init_time <- Sys.time()
  ## save out
  if(is.null(save_out_file)){
    save_out_file <- paste(format(init_time, "%Y%m%d_%H%M%S"), "abr_fit.RData", sep = "")
  }
  ## parameter storage
  chains <- lapply(initial_values, function(param){
    if(length(param) == 1){
      return(c(param, rep(NA, N_iterations)))
    } else if(is.null(dim(param))){
      return(cbind(as.numeric(param), matrix(NA, length(param), N_iterations)))
    } else {
      return(array(c(param, rep(NA, prod(dim(param))*N_iterations)),
                   dim = c(dim(param), N_iterations + 1)))
    }
  })
  ld_s <- get_ld_s(sigsq_s = chains$sigsq_s[1], sigsq_muos = chains$sigsq_muos[1],
                   s = data$s, Sigma_s_inv_list = data$Sigma_s_inv_list,
                   Sigma_s_log_det = data$Sigma_s_log_det, H = data$H)
  ## tuning parameters
  tuning_params <- lapply(initial_values[which(names(initial_values) != 'sigsq_s')], function(param){
    if(is.null(dim(param))){
      array(param, dim = floor(N_iterations/batch_size) + 1)
    } else {
      array(colMeans(param), dim = c(ncol(param), floor(N_iterations/batch_size) + 1))
    }
  })
  batch_no <- 1
  ## MCMC loop
  for(iter in 1 + 1:N_iterations){
    ## sigsq_s ----
    chains$sigsq_s[iter] <- chains$sigsq_s[iter - 1]
    if(!fixed_params$sigsq_s){
      chains$sigsq_s[iter] <- 
        sample_sigsq_s(sigsq_s = chains$sigsq_s[iter - 1], sigsq_muos = chains$sigsq_muos[iter - 1], 
                       s = data$s, C_inv = ld_s$C_inv, prior_params = prior_params$sigsq_s)
    }
    ## sigsq_muos ----
    chains$sigsq_muos[iter] <- chains$sigsq_muos[iter - 1]
    if(!fixed_params$sigsq_muos){
      sigsq_muos_draw <- sample_rw(prev = chains$sigsq_muos[iter - 1], 
                                   tune = tuning_params$sigsq_muos[batch_no],
                                   get_ld_fc = get_ld_fc_sigsq_muos, 
                                   # ld_fc_prev = NULL,
                                   ld_fc_prev = get_ld_s(sigsq_s = chains$sigsq_s[iter],
                                                         sigsq_muos = chains$sigsq_muos[iter - 1],
                                                         s = data$s, C_inv = ld_s$C_inv,
                                                         C_log_det = ld_s$C_log_det)$ld_s,
                                   sigsq_s = chains$sigsq_s[iter], 
                                   s = data$s, Sigma_s_inv_list = data$Sigma_s_inv_list, 
                                   Sigma_s_log_det = data$Sigma_s_log_det, H = data$H, 
                                   prior_params = prior_params$sigsq_muos)
      sigsq_muos_draw$draw
      chains$sigsq_muos[iter] <- sigsq_muos_draw$draw
      if(!is.null(sigsq_muos_draw$excess)){
        ld_s$C_inv <- sigsq_muos_draw$excess$C_inv
        ld_s$C_log_det <- sigsq_muos_draw$excess$C_log_det
      }
    }
    ## tuning ----
    if(iter %% batch_size == 1){
      batch_no = batch_no + 1
      for(param in names(tuning_params)){
        if(fixed_params[[param]]){
          tuning_params[[param]][batch_no] <- tuning_params[[param]][batch_no - 1]
        } else {
          if(is.null(dim(chains[[param]]))){
            tuning_params[[param]][batch_no] <- 
              update_tuning(batch = chains[[param]][(iter - batch_size - 1):iter], 
                            batch_no = batch_no, tuning_param = tuning_params[[param]][batch_no - 1])
          } else {
            for(sub_param in 1:nrow(tuning_params[[param]])){
              tuning_params[[param]][sub_param, batch_no] <- 
                update_tuning(batch = chains[[param]][1, sub_param, (iter - batch_size - 1):iter], 
                              batch_no = batch_no, tuning_param = tuning_params[[param]][sub_param, batch_no - 1])
            }
          }
        }
      }
    }
    ## timing ----
    if(iter %% timing_chkpt == 1){
      timing <- Sys.time() - init_time
      message(paste("iteration ", iter-1, " (", floor((iter-1)/N_iterations*100), "%)",
                    " [", signif(timing, 5), " ", attr(timing, "units"), "]", sep = ""))
    }
    ## save out ----
    # if(iter %% save_out_rate == 1 || iter == N_iterations + 1){
    # out <- list("N_iterations" = N_iterations, "initial_values" = initial_values,
    #             "fixed_params" = fixed_params, "prior_params" = prior_params, "data" = data,
    #             "tuning_params" = tuning_params, "timing" = timing,
    #             "chains" = chains)
    #   save(out, file = save_out_file)
    # }
  }
  out <- list("N_iterations" = N_iterations, "initial_values" = initial_values,
              "fixed_params" = fixed_params, "prior_params" = prior_params, "data" = data,
              "tuning_params" = tuning_params, "timing" = timing, "chains" = chains)
  return(out)
}