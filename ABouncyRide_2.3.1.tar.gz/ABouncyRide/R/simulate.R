################################################################################ ----
################################################################################ ----
## Henry Scharf
## 
## This script simulates paths from the ice boundary model.
################################################################################ ----
################################################################################ ----
#' Simulate ice boundaries
#'
#' @param ice_model \code{ice_model} object. List containing the following elements with these exact names:
#' \code{times}: numeric vector of times at which ice boundaries will be simulated
#' \code{longitudes}: numeric vector longitudes at which the latitude of the ice boundary will be simulated.
#' \code{phi.time}: range parameter for temporal smoothing (in Gaussian fucntion)
#' \code{phi.longitude}: range parameter for longitudinal smoothing (in Gaussian fucntion)
#' @param seed integer giving random seed
#'
#' @return \code{ice_simulation} object containing \code{times}, \code{latitudes}, \code{longitudes}, \code{phi.time}, and \code{phi.longitude}, which has a plot default.
simulate.ice_model <- function(ice_model = NULL, seed = NULL){
  if(!is.null(seed)){
    set.seed(seed)
  }
  if(is.null(ice_model)){
    ice_model <- list("times" = seq(0, 1, l=4e1), "longitudes" = seq(0, 1, l=3e2), 
                      "phi.time" = 1/10, "phi.longitude" = 1/30, 
                      "sigsq" = 1, rate = 1)
  }
  list2env(ice_model, envir = environment())
  time.knots <- seq(min(times), max(times), l=3/phi.time)
  longitude.knots <- seq(min(longitudes), max(longitudes), l = 3/phi.longitude)
  H.time <- t(c(0, diff(time.knots)) *
    t(smover::build.H(kernel = smover::kernel.samp()$kernel.gauss, phi = phi.time, 
                    warped.times = times, knots = time.knots, row.normalize = T)))
  H.longitude <- t(c(0, diff(longitude.knots)) * 
    t(smover::build.H(kernel = smover::kernel.samp()$kernel.gauss, phi = phi.longitude, 
                    warped.times = longitudes, knots = longitude.knots, row.normalize = T)))
  wn <- sqrt(sigsq) * matrix(rnorm(length(time.knots) * length(longitude.knots)), 
               length(longitude.knots), length(time.knots))
  latitudes <- H.longitude %*% wn
  latitudes <- t(H.time %*% t(latitudes) + rate * (times))
  out <- list("times" = times, "latitudes" = latitudes, "longitudes" = longitudes,
              "phi.longitude" = phi.longitude, "phi.time" = phi.time, 
              "rate" = rate)
  class(out) <- "ice_simulation"
  return(out)
}

#' Simulate a path from the ice boundary model
#'
#' @param abr_model \code{abr_model} object. List containing the following elements with these exact names:
#' \code{sigsq_mu}:
#' \code{sigsq_tm1}:
#' \code{sigsq_ac}:
#' \code{tausq}:
#' \code{mu_activity}:
#' \code{rho}:
#' \code{ice}: \code{ice_simulation} object, or list containing the same values.
#' @param sigsq_mu variance of combined \eqn{\mu(t-1)} and \eqn{\mu_{ac}} densities
#' @param rho location at which to evaluate density function 
#' @param sigsq_tm1 
#' @param sigsq_ac 
#' @param tausq ice availability variance
#' @param mu_activity 
#' @param ice 
#' @param seed 
#' @param method "ice_first" (default), "activity_first", or "exact". Ice first linearizes the effect of the ice at the point on the manifold closest to the previous location (\eqn{\mu(t-1)}). Activity first linearizes at the point on the ice closest to the convext combination of \eqn{\mu(t-1)} and \eqn{\mu_{activity center}} resulting from the CAR structure and a parameter rho. 
#' @param pixels integer number of pixels to use in normalizing integral (default is 200^2)
#' @param verbose 
#'
#' @return object of class \code{abr_simulation}, which has a plot default.
#' @export
simulate.abr_model <- function(abr_model = NULL, 
                               sigsq_mu = NULL, rho = NULL, 
                               sigsq_tm1 = NULL, sigsq_ac = NULL, 
                               tausq = 1, mu_activity = c(0.25, 0.5), 
                               mu_init = c(rnorm(2, c(0.5, 0), c(0.2, 0.02))),
                               ice = NULL, seed = 2017, 
                               method = "ice_first", pixels = 2e2^2, verbose = F){
  set.seed(seed)
  if(!is.null(abr_model)){
    list2env(abr_model, envir = environment())
  }
  list2env(ice, envir = environment())
  TIME <- length(times)
  ice.ind <- west.ind <- theta <- rep(NA, TIME)
  mu <- matrix(c(mu_init), TIME + 1, 2, byrow = T)
  mu.til <- m <- mean <- matrix(NA, TIME, 2)
  Sigma <- array(NA, dim = c(2, 2, TIME))
  if(method == "exact"){
    if(verbose) message("Using exact method.")
    if(is.null(sigsq_mu)){
      if(verbose) message("Determining sigsq_mu based on sigsq_tm1 and sigsq_ac.")
      sigsq_mu <- (sigsq_tm1^(-1) + sigsq_ac^(-1))^(-1)
    }
    if(is.null(rho)){
      if(verbose) message("Determining rho based on sigsq_tm1 and sigsq_ac.")
      rho <- sigsq_mu/sigsq_tm1
    } 
    for(t in 1:TIME){
      mu.til[t, ] <- (1 - rho) * mu_activity + rho * mu[t, ]
      distances <- colSums((mu.til[t, ] - rbind(longitudes[[t]], latitudes[[t]]))^2)
      ice.ind[t] <- which.min(distances)
      h <- sqrt(distances[ice.ind[t]])
      m[t, ] <- c(longitudes[[t]][ice.ind[t]], latitudes[[t]][ice.ind[t]])
      # theta[t] <- atan2(m[t, 2] - mu.til[t, 2], m[t, 1] - mu.til[t, 1])
      # R <- matrix(c(cos(theta[t]), sin(theta[t]), -sin(theta[t]), cos(theta[t])), 2, 2)
      ## get grid 
      right <- max(mu.til[t, 1] + 3*sqrt(sigsq_mu), m[t, 1] + 3*sqrt(tausq))
      left <- min(mu.til[t, 1] - 3*sqrt(sigsq_mu), m[t, 1] - 3*sqrt(tausq))
      top <- max(mu.til[t, 2] + 3*sqrt(sigsq_mu), m[t, 2] + 3*sqrt(tausq))
      bottom <- min(mu.til[t, 2] - 3*sqrt(sigsq_mu), m[t, 2] - 3*sqrt(tausq))
      grid <- expand.grid(seq(left, right, l=sqrt(pixels)), seq(bottom, top, l=sqrt(pixels)))
      prod.measure <- apply(grid, 1, function(x){
        h <- min(colSums((rbind(longitudes[[t]], latitudes[[t]]) - as.numeric(x))^2))
        d <- dist(rbind(as.numeric(x), mu.til[t, ]))
        return(-log(2*pi*sigsq_mu) - d^2/2/sigsq_mu -log(2*pi*tausq) - h/2/tausq)
      })
      mu[t + 1, ] <- as.numeric(grid[sample(1:dim(grid)[1], size = 1, prob = exp(prod.measure)), ])
    }
  } else if (method == "activity_first"){
    if(verbose) message("Using activity_first method.")
    if(is.null(sigsq_mu)){
      if(verbose) message("Determining sigsq_mu based on sigsq_tm1 and sigsq_ac.")
      sigsq_mu <- (sigsq_tm1^(-1) + sigsq_ac^(-1))^(-1)
    }
    if(is.null(rho)){
      if(verbose) message("Determining rho based on sigsq_tm1 and sigsq_ac.")
      rho <- sigsq_mu/sigsq_tm1
    } 
    for(t in 1:TIME){
      mu.til[t, ] <- (1 - rho) * mu_activity + rho * mu[t, ]
      distances <- colSums((mu.til[t, ] - rbind(longitudes[[t]], latitudes[[t]]))^2)
      ice.ind[t] <- which.min(distances)
      h <- sqrt(distances[ice.ind[t]])
      m[t, ] <- c(longitudes[[t]][ice.ind[t]], latitudes[[t]][ice.ind[t]])
      theta[t] <- atan2(m[t, 2] - mu.til[t, 2], m[t, 1] - mu.til[t, 1])
      R <- matrix(c(cos(theta[t]), sin(theta[t]), -sin(theta[t]), cos(theta[t])), 2, 2)
      Sigma[, , t] <- R %*% matrix(c((sigsq_mu^(-1) + tausq^(-1))^(-1), 0, 0, sigsq_mu), 2, 2) %*% t(R)
      mean[t, ] <- mu.til[t, ] + 
        R %*% matrix(c((sigsq_mu^(-1) + tausq^(-1))^(-1), 0, 0, sigsq_mu), 2, 2) %*% c(h, 0) / tausq
      mu[t + 1, ] <- chol(Sigma[, , t]) %*% rnorm(2) + mean[t, ]
    }
  } else if(method == "ice_first"){
    if(verbose) message("Using ice_first method.")
    if(is.null(sigsq_tm1)){
      if(verbose) message("Determining sigma_ac based on sigsq_mu and rho.")
      sigsq_ac <- (sigsq_mu^(-1) - sigsq_tm1^(-1))^(-1)
    } 
    if(is.null(sigsq_ac)){
      if(verbose) message("Determining sigsq_tm1 based on sigsq_mu and rho.")
      sigsq_tm1 <- sigsq_mu/rho
    }
    for(t in 1:TIME){
      distances <- colSums((mu[t, ] - rbind(longitudes[[t]], latitudes[[t]]))^2)
      ice.ind[t] <- which.min(distances)
      h <- sqrt(distances[ice.ind[t]])
      m[t, ] <- c(longitudes[[t]][ice.ind[t]], latitudes[[t]][ice.ind[t]])
      theta[t] <- atan2(m[t, 2] - mu[t, 2], m[t, 1] - mu[t, 1])
      R <- matrix(c(cos(theta[t]), sin(theta[t]), -sin(theta[t]), cos(theta[t])), 2, 2)
      Sigma. <- R %*% matrix(c((sigsq_tm1^(-1) + tausq^(-1))^(-1), 0, 0, sigsq_tm1), 2, 2) %*% t(R)
      Prec. <- solve(Sigma.)
      alpha <- sigsq_tm1 / (sigsq_tm1 + tausq)
      mean. <- alpha * m[t, ] + (1 - alpha) * mu[t, ]
      Sigma[, , t] <- solve(Prec. + sigsq_ac^(-1) * diag(2))
      mean[t, ] <- Sigma[, , t] %*% (Prec. %*% mean. + sigsq_ac^(-1) * mu_activity)
      mu[t + 1, ] <- chol(Sigma[, , t]) %*% rnorm(2) + mean[t, ]
    }
  }
  out <- list("mu" = mu, "mu.til" = mu.til, "m" = m, "mean" = mean, 
              "mu_activity" = mu_activity, "sigsq_mu" = sigsq_mu, "rho" = rho,
              "sigsq_tm1" = sigsq_tm1, "sigsq_ac" = sigsq_ac, "tausq" = tausq,
              "Sigma" = Sigma, "ice" = ice)
  class(out) <- "abr_simulation"
  return(out)
}