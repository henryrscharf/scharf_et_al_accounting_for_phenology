#' ABouncyRide
#' 
#' This package contains samplers and a parent function that fits a Bayesian hierarchical movement model to observations of polar bears.
#' 
#' @docType package
#' @author Henry Scharf
#' @import Rcpp
#' @name ABouncyRide
#' @useDynLib ABouncyRide
#' @importFrom Rcpp sourceCpp
NULL