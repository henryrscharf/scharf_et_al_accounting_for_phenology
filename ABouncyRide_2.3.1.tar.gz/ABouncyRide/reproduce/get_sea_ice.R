################################################################################ ----
################################################################################ ----
## Henry Scharf
##
## This script downloads sea ice shape files from ftp://sidads.colorado.edu/DATASETS/NOAA/G02186/shapefiles/4km/, unzips them, and compiles them into an RData file. It also projects the shape files. 
################################################################################ ----
################################################################################ ----
## libraries ----
library(rgdal); library(sp); library(rgeos)
## dates for ice ----
years <- 2012:2016
days.per.year <- c(366, 365, 365, 365, 366)
days <- unlist(sapply(days.per.year, function(dpy){1:dpy}))
dates <- paste(rep(years, days.per.year), formatC(days, width = 3, format = 'd', flag = '0'), sep = '')
missing.dates <- NULL
## get and save shapes [MEMORY INTENSIVE, recommend having at least 16GB of memory available] ----
system.time({
  system("mkdir sea_ice")
  system("mkdir sea_ice/zip")
  shapes <- sapply(dates, function(date){
    tryCatch(expr = {
      download.file(url = paste('ftp://sidads.colorado.edu/DATASETS/NOAA/G02186/shapefiles/4km/',
                                substring(date, 1, 4), '/masie_ice_r00_v01_', date, '_4km.zip', sep = ''),
                    destfile = paste('sea_ice/zip/masie_ice_r00_v01_', date, '_4km.zip', sep = ''))
      unzip(zipfile = paste('sea_ice/zip/masie_ice_r00_v01_', date, '_4km.zip', sep = ''),
            exdir = paste('sea_ice/', date, sep = ''))
      shape <<- readOGR(dsn = paste('sea_ice/', date, sep = ''),
                        layer = paste('masie_ice_r00_v01_', date, '_4km', sep = ''))
      file.remove(paste('sea_ice/zip/masie_ice_r00_v01_', date, '_4km.zip', sep = ''))
      file.remove(paste('sea_ice/', date, '/masie_ice_r00_v01_', date, '_4km',
                        c('.dbf', '.prj', '.shp', '.shx'), sep = ''))
      file.remove(paste('sea_ice/', date, sep = ''))
    }, error = function(err){
      message('file unavailable')
      file.remove(paste('sea_ice/', date, sep = ''))
      shape <<- NA
      missing.dates <<- c(missing.dates, date)
    })
  return(shape)
  })
})
## project the shapes to match the data ----
## define projection
pb.crs <- CRS(paste('+proj=aea +lat_1=60 +lat_2=90',
                    '+lat_0=82 +lon_0=-175 +x_0=0 +y_0=0',
                    '+ellps=GRS80 +datum=NAD83',
                    '+units=km +no_defs'))
system.time({
  shapes.proj <- lapply(shapes, function(shape){
    shape.proj <- NA
    tryCatch(expr = {
      shape.proj <- spTransform(shape, pb.crs)
    }, error = function(err){
      shape.proj <- NA
    })
    return(shape.proj)
  })
})
## save subsets by year ----
for(year in years){
  sub.dates <- sort(c(dates[grep(paste(year, 0, sep = ''), dates)],
                      dates[grep(paste(year, 1, sep = ''), dates)],
                      dates[grep(paste(year, 2, sep = ''), dates)],
                      dates[grep(paste(year, 3, sep = ''), dates)]))
  sub.shapes.proj <- shapes.proj[sub.dates]
  save(sub.shapes.proj, sub.dates,
       missing.dates, file = paste0('masie_ice_projected_', year, '.RData', sep = ''))
}
## combine sea ice and land into SpatialLines object ----
## load map file and project data with proper +proj4 projection details ----
data('land')
land.proj <- spTransform(land, pb.crs)
for(year in years){
  message('Now joining land and sea together in ', year, '!')
  message(Sys.time())
  ## load sea ice data ----
  load(paste('sea_ice/masie_ice_projected_', year, '.RData', sep = ''))
  shapes.proj <- sub.shapes.proj
  rm(sub.shapes.proj)
  dates <- strptime(sub.dates, format = '%Y%j', tz = 'UTC')
  rm(sub.dates)
  ## use previous day's ice measurements if needed + discard July 13th 2016 ----
  if(year == 2016){
    shapes.proj[[which(dates == as.POSIXct('2016-07-13', tz = 'UTC'))]] <- NA
  }
  tries <- 0
  while(sum(is.na(shapes.proj)) > 0 & tries < 20){
    for(day in which(is.na(shapes.proj))){
      shapes.proj[[day]] <- shapes.proj[[day - 1]]
    }
    tries <- tries + 1
  }
  ## join ice and coast into one manifold [~10 min per year] ----
  system.time({
    lines_ice_coast <- sapply(1:length(dates), function(date.i){
      date <- dates[date.i]
      # message('Now binding day ', date)
      land.proj.SP <- as(land.proj, 'SpatialLines')
      land.proj.SP <- spChFIDs(land.proj.SP, paste('land.proj.SP', 
                                                   row.names(land.proj.SP), sep='.'))
      shapes.proj.SP <- as(shapes.proj[[which(date == dates)]], 'SpatialLines')
      shapes.proj.SP <- spChFIDs(shapes.proj.SP, paste('shapes.proj.SP', 
                                                       row.names(shapes.proj.SP), sep='.'))
      return(sp::rbind.SpatialLines(shapes.proj.SP, land.proj.SP))
    })
  })
  save(lines_ice_coast, file = paste(year, '_lines_ice_coast.RData', sep = ''))
}
