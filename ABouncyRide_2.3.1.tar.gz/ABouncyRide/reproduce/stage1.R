################### ----
## PRELIMINARIES ## ----
################### ----
## libraries + seed ----
library(ABouncyRide); library(sp); library(rgdal)
library(crawl); library(xts); library(foreach)
library(ellipse)
set.seed(2017)
############### ----
## LOAD DATA ## ----
############### ----
## data ----
data('pb_2012_2016')
pb$lc94[pb$lc94 %in% c("LZ", "DP")] <- "LB"
## initial values for Argos error levels ----
theta_all <- c(log(0.01), log(0.1), log(0.487), log(0.939), log(1.110), log(4.342), log(31.512), log(36.077))
names(theta_all) <- c("ellipse", "GPS", "L3", "L2", "L1", "L0", "LA", "LB")
fixPar_all <- c(NA, NA, NA, NA, NA, NA, NA, NA)
names(fixPar_all) <- c("ellipse", "GPS", "L3", "L2", "L1", "L0", "LA", "LB")
############### ----
## PREP DATA ## ----
############### ----
## n.indiv ----
ids <- unique(pb$animal)
n.indiv <- length(ids)
n.indiv - length(grep("_1", unique(pb$animal)))
## uniqueify times ----
message(paste(
  sum(sapply(ids, function(id) sum(diff(as.numeric(pb$POSIX[pb$animal == id])) == 0))), 
  "duplicate times detected"))
pb$POSIX <- make.time.unique(pb$POSIX, eps = 1)
## project data [+proj4 projection details] ----
coordinates(pb) <- ~longitud+latitude
proj4string(pb) <- CRS("+proj=longlat")
## note units: kilometers
pb.crs <- CRS(paste("+proj=aea +lat_1=60 +lat_2=90",
                    "+lat_0=82 +lon_0=-175 +x_0=0 +y_0=0",
                    "+ellps=GRS80 +datum=NAD83",
                    "+units=km +no_defs"))
pb.proj <- spTransform(pb, pb.crs)
########### ----
## CRAWL ## ----
########### ----
## crawl fit ---- 
K_crawl <- 24; max_tries <- 25; max_attempts <- 10
log_sigsq <- 1
beta_init <- 9
system.time({
  bad_ids <- NULL
  mu_stars <- vector("list", length(ids))
  for(id in ids){
    message(paste("individual", which(id == ids), "out of", n.indiv))
    pb_id <- pb.proj[pb.proj$animal == id, ]
    if(dim(pb_id)[1] < 3){
      message("Fewer than 3 data points, removing individual ", id, " from study.")
      mu_stars[[which(id == ids)]] <- NULL
      next
    }
    mu_star <- vector("list", K_crawl)
    initial <- list(a = c(coordinates(pb_id)[1, 1], 0,
                          coordinates(pb_id)[1, 2], 0),
                    P = diag(rep(c(1e4, 1e2), 2)))
    data <- data.frame("x" = pb_id@coords[, 1],
                       "y" = pb_id@coords[, 2],
                       "times" = pb_id$POSIX)
    ## single parameter for GPS, or multi-parameter for Argos without ellipse info ----
    if(!("Argos" %in% unique(pb_id$Loctype))){
      message("No Argos errors for this individual. Using single parameter Gaussian-shaped errors.")
      fixPar <- c(NA, NA, NA)
      error_model <- list(x = ~1)
      theta <- c(theta_all['GPS'], log_sigsq, beta_init)
      ln.prior <- function(theta){
        dnorm(theta[1], mean = theta_all['GPS'], sd = 3, log = T) +
          dnorm(theta[length(theta) - 1], mean = log_sigsq, sd = 1) +
          dnorm(theta[length(theta)], mean = beta_init, sd = 2, log = T)
      }
    } else {
      ## REMEMBER: Argos ellipses are in meters
      SMA_zeroed <- pb_id$Semi.major.axis
      SMA_zeroed[is.na(SMA_zeroed)] <- 0; SMA_zeroed[SMA_zeroed == 0] <- 1e2
      SmA_zeroed <- pb_id$Semi.minor.axis
      SmA_zeroed[is.na(SmA_zeroed)] <- 0; SmA_zeroed[SmA_zeroed == 0] <- 1e2
      EO_zeroed <- pb_id$Ellipse.orientation; EO_zeroed[is.na(EO_zeroed)] <- 0
      argos_covs <- argosDiag2Cov(Major = SMA_zeroed*1e-3, 
                                  Minor = SmA_zeroed*1e-3, 
                                  Orientation = EO_zeroed)
      ## GPS indicator variable
      loc_class <- (pb_id$Loctype %in% c("GPS", "Iridium"))
      loc_class[loc_class == "TRUE"] <- "GPS"
      loc_class[pb_id$Loctype == "Argos" & is.na(pb_id$Semi.major.axis)] <- 
        pb_id$lc94[pb_id$Loctype == "Argos" & is.na(pb_id$Semi.major.axis)]
      loc_class[pb_id$Loctype == "Argos" & !is.na(pb_id$Semi.major.axis)] <- "ellipse"
      for(level in unique(loc_class)){
        if(sum(loc_class == level) == 1){
          pb_id <- pb_id[loc_class != level, ]
          data <- data[loc_class != level, ]
          argos_covs <- argos_covs[loc_class != level, ]
          loc_class <- loc_class[loc_class != level]
        }
      }
      n_var_par <- length(unique(loc_class))
      error_model <- list(
        x = ~ ln.sd.x + loc_class - 1, 
        y = ~ ln.sd.y + loc_class - 1, 
        rho = ~ error.corr
      )
      fixPar <- c(rep(c(NA, fixPar_all[unique(sort(loc_class))]), 2), NA, NA)
      theta <- c(rep(c(1, theta_all[unique(sort(loc_class[loc_class %in% names(theta_all)]))]), 2), log_sigsq, beta_init)
      ln.prior <- function(theta){
        sum(dnorm(theta[1:(length(theta) - 2)], 
                  mean = rep(c(0, theta_all[unique(sort(loc_class[loc_class %in% names(theta_all)]))]), 2), 
                  sd = 3, log = T)) +
          dnorm(theta[length(theta) - 1], mean = log_sigsq, sd = 1) +
          dnorm(theta[length(theta)], mean = beta_init, sd = 2, log = T)
      }
      if(sum(argos_covs$error.corr != 0) == 0){
        error_model <- list(
          x = ~ loc_class - 1
        )
        fixPar <- c(rep(c(fixPar_all[unique(sort(loc_class))]), 1), NA, NA)
        theta <- c(rep(c(theta_all[unique(sort(loc_class[loc_class %in% names(theta_all)]))]), 1), log_sigsq, beta_init)
        ln.prior <- function(theta){
          sum(dnorm(theta[1:(length(theta) - 2)], 
                    mean = rep(c(theta_all[unique(sort(loc_class[loc_class %in% names(theta_all)]))]), 1), 
                    sd = 3, log = T)) +
            dnorm(theta[length(theta) - 1], mean = log_sigsq, sd = 1) +
            dnorm(theta[length(theta)], mean = beta_init, sd = 2, log = T)
        }
      }
      if(sum(!(loc_class %in% c("ellipse", "GPS"))) == 0){
        error_model <- list(
          x = ~ ln.sd.x - 1, 
          y = ~ ln.sd.y - 1, 
          rho = ~ error.corr
        )
        fixPar <- c(NA, NA, NA, NA)
        theta <- c(1, 1, log_sigsq, beta_init)
        ln.prior <- function(theta){
          sum(dnorm(theta[1:2], mean = 0, sd = 3, log = T)) +
            dnorm(theta[length(theta) - 1], mean = log_sigsq, sd = 1) +
            dnorm(theta[length(theta)], mean = beta_init, sd = 2, log = T)
        }
      }
      data <- cbind(data, argos_covs, loc_class)
      if(n_var_par == 1){
        error_model <- list(
          x = ~ ln.sd.x - 1, 
          y = ~ ln.sd.y - 1, 
          rho = ~ error.corr
        )
        fixPar <- c(NA, NA, NA, NA)
        theta <- c(1, 1, log_sigsq, beta_init)
        ln.prior <- function(theta){
          sum(dnorm(theta[1:2], mean = 0, sd = 3, log = T)) +
            dnorm(theta[length(theta) - 1], mean = log_sigsq, sd = 1) +
            dnorm(theta[length(theta)], mean = beta_init, sd = 2, log = T)
        }
      }
    }
    ## displayPar + prior ----
    displayPar(mov.model = ~1,
               err.model = error_model,
               data = data, 
               theta = theta,
               fixPar = fixPar)
    ln.prior
    ## prediction times ----
    range_year <- range(format(pb_id$POSIX, "%Y"))
    range_day <- c(max(1, min(as.numeric(format(pb_id$POSIX[format(pb_id$POSIX, "%Y") == range_year[1]], "%j")) - 1)),
                   max(as.numeric(format(pb_id$POSIX[format(pb_id$POSIX, "%Y") == range_year[2]], "%j"))))
    pred_times <- seq(as.POSIXct(x = paste(range_year[1], as.numeric(range_day[1])), 
                                 format = "%Y %j", tz = "UTC"),
                      as.POSIXct(x = paste(range_year[2], as.numeric(range_day[2]) + 1), 
                                 format = "%Y %j", tz = "UTC"), by = "day")
    pred_times <- pred_times[pred_times >= min(pb_id$POSIX)]
    ## catch the extremely unlikely event that a prediction time exactly matches an observation time
    match <- which(data$times %in% pred_times)
    ## if only one pred time then just sample observed locations ----
    if(length(pred_times) == 1){
      mu_star <- sapply(1:K_crawl, function(k){
        matrix(pb_id@coords[sample(1:nrow(pb_id), 1), ], ncol = 2)
      }, simplify = F)
      out <- list("K_crawl" = K_crawl, "interp.times" = pred_times,
                  "basis_func" = "crawl", "mu.star" = mu_star,
                  "s" = pb_id@coords, "observation_times" = pb_id$POSIX,
                  "fit1_crawl" = fit1_crawl, "id" = id)
      class(out) <- "fit1_crawl"
      mu_stars[[which(id == ids)]] <- out
      next
    }
    ## set up ARGOS-type error structure if orientiation data are available, 
    ## crwMLE ----
    tries <- 0; out <- NULL
    while(tries < max_tries){
      tries <- tries + 1
      message(paste("try number", tries))
      tryCatch(expr = {
        fit1_crawl <- crwMLE(mov.model = ~1, 
                             err.model = error_model,
                             data = data,
                             Time.name = "times",
                             initial.state = initial, 
                             theta = theta,
                             prior = ln.prior,
                             method = "L-BFGS-B", 
                             need.hess = T,
                             fixPar = fixPar, attempts = max_attempts,
                             initialSANN = list(maxit = 300))
        simObj <- crwSimulator(object.crwFit = fit1_crawl, predTime = pred_times, 
                               parIS = 2e2, method = "IS")
        sigsq_s_draw <- rep(NA, K_crawl)
        for(i in 1:K_crawl){
          if(nrow(data) == 3){
            samp <- crwPostIS(object.sim = simObj, fullPost = F)
          } else {
            samp <- crwPostIS(object.sim = simObj)
          }
          samp$locType[samp$locType == "o"][match] <- "p"
          mu_star[[i]] <- cbind(samp$alpha.sim[samp$locType == "p", "mu.x"],
                                samp$alpha.sim[samp$locType == "p", "mu.y"])
          sigsq_s_draw[i] <- samp$par[1]
        }
        out <- list("K_crawl" = K_crawl, "interp.times" = pred_times,
                    "basis_func" = "crawl", "mu.star" = mu_star,
                    "s" = pb_id@coords, "observation_times" = pb_id$POSIX,
                    "fit1_crawl" = fit1_crawl, "id" = id)
        class(out) <- "fit1_crawl"
        tries <- max_tries
      },
      error = function(err){
        if(tries == max_tries){
        bad_ids <- c(bad_ids, id)
        stop(message("######################################### \n",
                     "## ERROR: Max number of tries reached! \n",
                     "## Individual: ", id, "\n", 
                     "#########################################"))
        }
      })
    }
    ## return value ----
    mu_stars[[which(id == ids)]] <- out
  }
})
## save output ----
save(mu_stars, bad_ids, file = 'stage1_paths.RData')
########### ----
## PLOTS ## ----
########### ----
## filename ----
rows <- 41
pdf(file = 'stage1_paths.pdf', width = 17, height = rows * 17 / 5)
## plot commands: path draws individuals ----
layout(matrix(1:(rows * 5), rows, 5, byrow = T))
par(mar = c(3.1, 3.1, 1.1, 1.1))
device.color <- c("GPS" = scales::muted("green"), "Argos" = scales::muted("red"))
for(id in ids){
  device.type <- as.character(pb$Loctype[pb$animal == id][1])
  if(!is.null(mu_stars[[which(id == ids)]])){
    plot(mu_stars[[which(id == ids)]], line.col = device.color[device.type], main = id, asp = 1)
  }
}
## dev.off ----
dev.off()
