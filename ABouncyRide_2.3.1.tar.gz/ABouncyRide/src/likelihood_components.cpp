#include "RcppArmadillo.h"
#include <Rcpp.h>
using namespace Rcpp;
using namespace arma;

#include <RcppArmadillo.h>

const double log2pi = std::log(2.0 * M_PI);

arma::vec dmvnrm_arma(arma::mat x,  
                      arma::rowvec mean,  
                      arma::mat sigma, 
                      bool logd = false) { 
  int n = x.n_rows;
  int xdim = x.n_cols;
  arma::vec out(n);
  arma::mat rooti = arma::trans(arma::inv(trimatu(arma::chol(sigma))));
  double rootisum = arma::sum(log(rooti.diag()));
  double constants = -(static_cast<double>(xdim)/2.0) * log2pi;
  
  for (int i=0; i < n; i++) {
    arma::vec z = rooti * arma::trans( x.row(i) - mean) ;    
    out(i)      = constants - 0.5 * arma::sum(z%z) + rootisum;     
  }  
  
  if (logd == false) {
    out = exp(out);
  }
  return(out);
}

//' Compute the log density of \eqn{\boldsymbol\mu_t}.
//' 
//' This function does something important.
//'
//' @param mu_t 
//' @param mu_tm1 
//' @param sigsq_mu variance of \eqn{\mu(t - 1)}
//' @param m_t closest location on the ice boundary \eqn{\mathcal{M}(t)} to \eqn{\mu(t - 1)}
//' @param tausq affinity for \eqn{\mathcal{M}(t)}
//' @param ps vector of \code{n_sub_pops} probabilities corresponding to each class (should sum to 1).
//' @param mu_acs means of activity centers provided as matrix with two rows (easting, northing).
//' @param Prec_acs precision matrices associated with activity centers given as array with dimensions \code{2, 2, n_sub_pops}.
//' @export
// [[Rcpp::export]]
double get_ld_mu_t(const arma::vec mu_t, 
                   const arma::vec mu_tm1, 
                   const double sigsq_mu, 
                   const arma::vec m_t, 
                   const double tausq, 
                   const arma::vec ps, 
                   const arma::mat mu_acs, 
                   const arma::cube Prec_acs) {
  double theta = atan2(m_t(1) - mu_tm1(1), m_t(0) - mu_tm1(0)); 
  arma::mat R(2, 2);
  R(0, 0) = cos(theta);
  R(1, 0) = sin(theta);
  R(0, 1) = -sin(theta);
  R(1, 1) = cos(theta);
  double sigsq_mu_inv = pow(sigsq_mu, -1);
  double tausq_inv = pow(tausq, -1);
  arma::mat Q(2, 2);
  Q(0, 0) = sigsq_mu_inv + tausq_inv;
  Q(1, 0) = 0;
  Q(0, 1) = 0;
  Q(1, 1) = sigsq_mu_inv;
  arma::mat Prec_mv = R * Q * R.t();
  double alpha = sigsq_mu / (sigsq_mu + tausq);
  arma::vec mean_mv = alpha * m_t + (1-alpha) * mu_tm1;
  arma::cube Precs = Prec_acs;
  Precs.slice(0) = Prec_mv + Prec_acs.slice(0);
  Precs.slice(1) = Prec_mv + Prec_acs.slice(1);
  arma::cube Sigmas = Precs;
  Sigmas.slice(0) = Precs.slice(0).i();
  Sigmas.slice(1) = Precs.slice(1).i();
  arma::vec sub_pop_ld(2);
  arma::mat Prec_mv_mean_mv = Prec_mv * mean_mv;
  for(int sub_pop = 0; sub_pop < 2; sub_pop++){
    arma::vec mean = Sigmas.slice(sub_pop) * (Prec_mv_mean_mv + Prec_acs.slice(sub_pop) * mu_acs.col(sub_pop));
    arma::rowvec pdf_x = mu_t.t();
    arma::vec pdf = dmvnrm_arma(pdf_x, mean.t(), Sigmas.slice(sub_pop));
    sub_pop_ld(sub_pop) = ps(sub_pop) * pdf(0);
  }
  double out = log(sum(sub_pop_ld));
  return out;
}


//' Compute the log density of \eqn{\boldsymbol\mu} for all times t > 1..
//'
//' @param mu matrix with dimensions # times + 1, 2
//' @param sigsq_mu 
//' @param m matrix with dimension (# times, 2).
//' @param days 
//' @param tausq either a scalar, or a vector of values with length # times
//' @param summer 
//' @param ps scalar between 0 and 1
//' @param mu_acs means of activity centers provided as matrix with two rows (easting, northing).
//' @param Prec_acs precision matrices associated with activity centers given as array with dimensions \code{2, 2, n_sub_pops}.
//'
//' @return scalar
//' @export
// [[Rcpp::export]]
double get_ld_mu(const arma::mat mu, 
                 const double sigsq_mu, 
                 const arma::mat m, 
                 const arma::vec days, 
                 const double tausq, 
                 const arma::vec summer,
                 const double ps, 
                 const arma::mat mu_acs, 
                 const arma::cube Prec_acs){
  arma::vec ps_vec(2);
  ps_vec(0) = (1 - ps);
  ps_vec(1) = ps;
  arma::vec tausq_vec(days.n_elem);
  tausq_vec.fill(datum::inf);
  arma::vec summer_days = intersect(summer, days) - days(0);
  for(int day_i = 0; day_i < summer_days.n_elem; day_i++){
    tausq_vec(summer_days(day_i)) = tausq;
  }
  arma::vec lds(mu.n_rows - 1);
  for(int t = 1; t < mu.n_rows; t++){
    lds(t - 1) = get_ld_mu_t(mu.row(t).t(), mu.row(t - 1).t(), sigsq_mu, m.row(t - 1).t(), tausq_vec(t - 1), ps_vec, mu_acs, Prec_acs);
  }
  return(sum(lds));
}

